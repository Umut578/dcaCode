const WINDOW_MS = 60_000;
const MAX_REQUESTS = 20;
const MAX_BODY = 256 * 1024;
const buckets = new Map(); // Best-effort per-instance throttle; use Redis/Upstash for durable global limits.

function cors(req, res) {
  const origin = req.headers.origin;
  const allowed = (process.env.ALLOWED_ORIGINS || '').split(',').map(x => x.trim()).filter(Boolean);
  if (origin && allowed.length && !allowed.includes(origin)) return false;
  if (origin && allowed.includes(origin)) res.setHeader('Access-Control-Allow-Origin', origin);
  res.setHeader('Vary', 'Origin');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  res.setHeader('Access-Control-Max-Age', '600');
  return true;
}

function rateLimit(req) {
  const forwarded = req.headers['x-forwarded-for'];
  const ip = (typeof forwarded === 'string' ? forwarded.split(',')[0] : 'unknown').trim();
  const now = Date.now();
  let entry = buckets.get(ip);
  if (!entry || now - entry.start >= WINDOW_MS) entry = { start: now, count: 0 };
  entry.count += 1;
  buckets.set(ip, entry);
  if (buckets.size > 5000) {
    for (const [key, value] of buckets) if (now - value.start >= WINDOW_MS) buckets.delete(key);
  }
  return entry.count <= MAX_REQUESTS;
}

module.exports = async function handler(req, res) {
  if (!cors(req, res)) return res.status(403).json({ error: 'Origin not allowed' });
  if (req.method === 'OPTIONS') return res.status(204).end();
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  if (!process.env.OPENROUTER_API_KEY) return res.status(503).json({ error: 'AI service is not configured' });
  if (!rateLimit(req)) return res.status(429).json({ error: 'Rate limit exceeded. Try again later.' });

  try {
    let body;
    if (req.body && typeof req.body === 'object') {
      body = req.body;
      if (Buffer.byteLength(JSON.stringify(body)) > MAX_BODY) return res.status(413).json({ error: 'Request too large' });
    } else {
      let raw = '';
      for await (const chunk of req) {
        raw += chunk;
        if (Buffer.byteLength(raw) > MAX_BODY) return res.status(413).json({ error: 'Request too large' });
      }
      body = JSON.parse(raw || '{}');
    }
    if (!body || typeof body !== 'object' || !Array.isArray(body.messages)) return res.status(400).json({ error: 'Invalid request' });
    if (body.messages.length > 45) return res.status(400).json({ error: 'Too many messages' });
    if (typeof body.model !== 'string' || body.model.length > 160) return res.status(400).json({ error: 'Invalid model' });
    if (body.stream !== true) return res.status(400).json({ error: 'Streaming requests only' });

    const upstream = await fetch('https://openrouter.ai/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.OPENROUTER_API_KEY}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': process.env.APP_URL || 'https://dcacode.vercel.app',
        'X-Title': 'dcaCode'
      },
      body: JSON.stringify(body)
    });
    res.statusCode = upstream.status;
    res.setHeader('Content-Type', upstream.headers.get('content-type') || 'application/json');
    res.setHeader('Cache-Control', 'no-store');
    res.setHeader('X-Content-Type-Options', 'nosniff');
    if (!upstream.body) return res.end();
    const reader = upstream.body.getReader();
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      if (!res.write(Buffer.from(value))) await new Promise(resolve => res.once('drain', resolve));
    }
    res.end();
  } catch (error) {
    if (!res.headersSent) res.status(400).json({ error: 'Invalid request or upstream connection failed' });
    else res.end();
  }
};
