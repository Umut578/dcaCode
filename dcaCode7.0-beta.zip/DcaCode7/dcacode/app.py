"""dcaCode - terminal coding workspace. Pure Python standard library (curses)."""
import locale
import os
import queue
import re
import shlex
import signal
import subprocess
import sys
import threading
import time
from pathlib import Path

try:
    import curses
except ImportError:  # e.g. native Windows
    curses = None

from . import __version__
from .agent import Cancelled, OpenRouter
from .config import DEFAULT_MODEL, effective_key, load_config, save_config, validate_api_key
from .agent import PROXY_URL
from .extras import (IGNORED, SUPPORTED, TEMPLATES, TEMPLATE_INFO, build_content, create_project,
                     dropped_path, extract_files, fence_for, human, list_skills, load_attachment,
                     make_zip, skill_template, skills_prompt, valid_skill_name)
from .highlight import CMT, DEF, KW, NUM, STR, highlight_line, language_for

CMD_TIMEOUT = 120
MAX_FILE = 1000000
MAX_LOG = 2000
MAX_ATTACH = 60000
RUNNERS = {
    ".py": [sys.executable or "python3"], ".sh": ["bash"], ".js": ["node"],
    ".pl": ["perl"], ".rb": ["ruby"], ".php": ["php"], ".lua": ["lua"],
}
ANSI = re.compile(r"\x1b\[[0-?]*[ -/]*[@-~]|\x1b\][^\x07]*\x07")
CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f]")

HELP = [
    "Ctrl+S  save                 Ctrl+O  open path / new file",
    "Ctrl+F  find                 Ctrl+G  go to line",
    "Ctrl+Z  undo                 Ctrl+Y  redo",
    "Ctrl+E  API key / model      Ctrl+L  choose model from catalog",
    "F5      save + run file      F6      next pane (Esc = editor)",
    "Ctrl+Arrow  switch panels: ← files, → editor, ↓ terminal, ↑ AI chat",
    "F2      refresh file tree    Ctrl+Q  quit",
    "F7      attach file/photo/folder   F8  new project   F9  skills",
    "",
    "Tree:     Up/Down move, Enter/Right open or expand, Left collapse",
    "Terminal: Enter runs a command, Ctrl+C stops it, Up/Down history",
    "          'cd dir' changes the terminal directory",
    "          '!cmd' runs interactively (vim, python -i, ...)",
    "Chat:     Enter sends, Ctrl+C cancels a running answer",
    "          /file <question>  attach the open file",
    "          /apply [n]        put code block n (default last) in the editor",
    "          /attach <path>    send a file, photo or folder (or drop/paste its path)",
    "          /skill, /new, /project, /write, /share   (type /help in the chat)",
    "          /clear            reset conversation     /help",
    "PgUp/PgDn scroll the focused terminal or chat pane.",
]

CHAT_HELP = [
    "/attach [path]   file, photo, audio, video, iso or folder (F7 = file picker); pasted/dropped paths work too",
    "/detach          drop pending attachments      /file <question>  attach the open file",
    "/skill [use|off|show|new] <name>   skills change how the AI works (F9 picker)",
    "/new <name> [python|web|bash|empty]   new project;  /new <name> ask <description>  lets the AI build it",
    "/project <path>  switch project folder",
    "/write           create the files the AI proposed (file=path blocks), with confirmation",
    "/share [created] zip the project (or only AI-created files) into dcacode-share/",
    "/apply [n]       put code block n of the last answer into the editor    /clear  reset",
    "Ctrl+C cancels a running answer.",
]

A = {}
SYN = [0, 0, 0, 0, 0]


def clean(text):
    text = ANSI.sub("", text).replace("\t", "    ")
    return CTRL.sub("", text)


def init_colors():
    c = curses
    for k in ("def", "kw", "str", "cmt", "num", "title", "head", "headf", "err", "user",
              "lineno", "dir", "sel", "status", "sep", "dim", "ok", "box"):
        A[k] = c.A_NORMAL
    A["sel"] = c.A_REVERSE
    A["title"] = A["status"] = A["head"] = c.A_REVERSE
    A["headf"] = c.A_REVERSE | c.A_BOLD
    A["kw"] = A["user"] = A["dir"] = c.A_BOLD
    A["dim"] = A["lineno"] = A["cmt"] = c.A_DIM
    if c.has_colors():
        try:
            c.start_color()
            try:
                c.use_default_colors()
                bg = -1
            except c.error:
                bg = c.COLOR_BLACK

            def pair(n, fg, b=bg):
                c.init_pair(n, fg, b)
                return c.color_pair(n)

            A["kw"] = pair(1, c.COLOR_MAGENTA) | c.A_BOLD
            A["str"] = pair(2, c.COLOR_GREEN)
            A["cmt"] = pair(3, c.COLOR_CYAN)
            A["num"] = pair(4, c.COLOR_YELLOW)
            A["title"] = pair(5, c.COLOR_BLACK, c.COLOR_CYAN)
            A["head"] = pair(6, c.COLOR_BLACK, c.COLOR_WHITE)
            A["headf"] = pair(7, c.COLOR_BLACK, c.COLOR_YELLOW) | c.A_BOLD
            A["err"] = pair(8, c.COLOR_RED) | c.A_BOLD
            A["user"] = pair(9, c.COLOR_CYAN) | c.A_BOLD
            A["lineno"] = pair(10, c.COLOR_YELLOW) | c.A_DIM
            A["dir"] = pair(11, c.COLOR_CYAN) | c.A_BOLD
            A["status"] = pair(12, c.COLOR_BLACK, c.COLOR_GREEN)
            A["sep"] = pair(13, c.COLOR_BLUE)
            A["ok"] = pair(14, c.COLOR_GREEN)
        except c.error:
            pass
    SYN[:] = [A["def"], A["kw"], A["str"], A["cmt"], A["num"]]


def put(win, y, x, text, attr=0):
    h, w = win.getmaxyx()
    if y < 0 or y >= h or x >= w or not text:
        return
    if x < 0:
        text = text[-x:]
        x = 0
    text = text[: w - x]
    if y == h - 1 and x + len(text) >= w:
        text = text[: w - x - 1]
    if not text:
        return
    try:
        win.addstr(y, x, text, attr)
    except curses.error:
        pass


# --------------------------------------------------------------------------- widgets
class LineEdit:
    def __init__(self, text="", mask=False):
        self.text = text
        self.pos = len(text)
        self.mask = mask
        self.hist = []
        self.hi = None

    def paste(self, s):
        s = clean(s).replace("\n", " ").replace("\r", " ")
        self.text = self.text[: self.pos] + s + self.text[self.pos:]
        self.pos += len(s)

    def remember(self):
        if self.text.strip() and (not self.hist or self.hist[-1] != self.text):
            self.hist.append(self.text)
        self.hi = None

    def _bs(self):
        if self.pos > 0:
            self.text = self.text[: self.pos - 1] + self.text[self.pos:]
            self.pos -= 1

    def key(self, k):
        if isinstance(k, int):
            if k == curses.KEY_LEFT:
                self.pos = max(0, self.pos - 1)
            elif k == curses.KEY_RIGHT:
                self.pos = min(len(self.text), self.pos + 1)
            elif k == curses.KEY_HOME:
                self.pos = 0
            elif k == curses.KEY_END:
                self.pos = len(self.text)
            elif k == curses.KEY_BACKSPACE:
                self._bs()
            elif k == curses.KEY_DC:
                self.text = self.text[: self.pos] + self.text[self.pos + 1:]
            elif k == curses.KEY_UP and self.hist:
                self.hi = len(self.hist) - 1 if self.hi is None else max(0, self.hi - 1)
                self.text = self.hist[self.hi]
                self.pos = len(self.text)
            elif k == curses.KEY_DOWN and self.hi is not None:
                self.hi += 1
                if self.hi >= len(self.hist):
                    self.hi = None
                    self.text = ""
                else:
                    self.text = self.hist[self.hi]
                self.pos = len(self.text)
            return None
        if k in ("\n", "\r"):
            return "enter"
        if k == "\x1b":
            return "esc"
        if k == "\t":
            return "tab"
        if k in ("\x7f", "\b"):
            self._bs()
        elif k == "\x15":
            self.text = self.text[self.pos:]
            self.pos = 0
        elif k == "\x17":
            left = self.text[: self.pos].rstrip()
            cut = left.rfind(" ") + 1
            self.text = self.text[:cut] + self.text[self.pos:]
            self.pos = cut
        elif k == "\x01":
            self.pos = 0
        elif k.isprintable():
            self.text = self.text[: self.pos] + k + self.text[self.pos:]
            self.pos += 1
        return None

    def draw(self, win, y, x, w, prefix=""):
        shown = "*" * len(self.text) if self.mask else self.text
        avail = max(1, w - len(prefix))
        start = max(0, self.pos - avail + 1)
        put(win, y, x, prefix, A["dim"])
        put(win, y, x + len(prefix), shown[start:start + avail])
        return x + len(prefix) + self.pos - start


class Log:
    def __init__(self):
        self.entries = []  # [style, text]
        self.offset = 0

    def add(self, style, text):
        self.entries.append([style, clean(text)])
        if len(self.entries) > MAX_LOG:
            del self.entries[:500]

    def clear(self):
        self.entries = []
        self.offset = 0

    @staticmethod
    def _segments(text, width):
        out = []
        for part in text.split("\n"):
            if not part:
                out.append("")
            else:
                out.extend(part[i:i + width] for i in range(0, len(part), width))
        return out

    def total(self, width):
        return sum(len(self._segments(t, width)) for _, t in self.entries)

    def scroll(self, delta, width, rows):
        top = max(0, self.total(width) - rows)
        self.offset = max(0, min(self.offset + delta, top))

    def tail(self, width, rows):
        need = rows + self.offset
        out = []
        for style, text in reversed(self.entries):
            for s in reversed(self._segments(text, width)):
                out.append((style, s))
            if len(out) >= need:
                break
        out.reverse()
        if len(out) > need:
            out = out[-need:]
        if self.offset:
            out = out[: max(0, len(out) - self.offset)]
        return out[-rows:]


class Editor:
    def __init__(self):
        self.load("", None)

    def load(self, text, path):
        self.crlf = "\r\n" in text
        text = text.replace("\r\n", "\n").replace("\r", "\n")
        self.lines = text.split("\n")
        self.path = path
        self.spec = language_for(path)
        self.cy = self.cx = self.want = 0
        self.top = self.left = 0
        self.dirty = False
        self.undo, self.redo = [], []
        self.kind = None
        self.hl_states = [None]
        self.hl_valid = 0

    def text(self):
        s = "\n".join(self.lines)
        return s.replace("\n", "\r\n") if self.crlf else s

    def is_blank(self):
        return self.path is None and not self.dirty and self.lines == [""]

    # -- highlighting cache
    def invalidate(self, k):
        k = max(0, k)
        if k < self.hl_valid:
            self.hl_valid = k
            del self.hl_states[k + 1:]

    def state_at(self, i):
        if not self.spec:
            return None
        st = self.hl_states
        while self.hl_valid < i and self.hl_valid < len(self.lines) - 1:
            ln = self.lines[self.hl_valid]
            if len(ln) > 3000:
                ns = st[self.hl_valid]
            else:
                ns = highlight_line(ln, self.spec, st[self.hl_valid])[1]
            st.append(ns)
            self.hl_valid += 1
        return st[min(i, self.hl_valid)]

    def set_path(self, path):
        self.path = path
        self.spec = language_for(path)
        self.hl_states = [None]
        self.hl_valid = 0

    # -- undo
    def snap(self, kind):
        self.invalidate(self.cy - 1)
        self.dirty = True
        if kind in ("type", "back", "del") and kind == self.kind:
            return
        self.undo.append((list(self.lines), self.cy, self.cx))
        if len(self.undo) > 200:
            self.undo.pop(0)
        self.redo = []
        self.kind = kind

    def do_undo(self):
        if self.undo:
            self.redo.append((list(self.lines), self.cy, self.cx))
            self.lines, self.cy, self.cx = self.undo.pop()
            self._after_restore()

    def do_redo(self):
        if self.redo:
            self.undo.append((list(self.lines), self.cy, self.cx))
            self.lines, self.cy, self.cx = self.redo.pop()
            self._after_restore()

    def _after_restore(self):
        self.kind = None
        self.dirty = True
        self.want = self.cx
        self.invalidate(0)

    def replace_all(self, text):
        self.snap("apply")
        self.lines = text.replace("\r\n", "\n").split("\n")
        self.cy = self.cx = self.want = 0
        self.invalidate(0)

    # -- editing
    def insert_text(self, s):
        s = s.replace("\t", "    ")
        if not s:
            return
        parts = s.split("\n")
        self.snap("paste" if len(parts) > 1 else "type")
        line = self.lines[self.cy]
        before, after = line[: self.cx], line[self.cx:]
        if len(parts) == 1:
            self.lines[self.cy] = before + s + after
            self.cx += len(s)
        else:
            self.lines[self.cy] = before + parts[0]
            self.lines[self.cy + 1:self.cy + 1] = parts[1:-1] + [parts[-1] + after]
            self.cy += len(parts) - 1
            self.cx = len(parts[-1])
        self.want = self.cx

    def newline(self):
        self.snap("nl")
        line = self.lines[self.cy]
        before, after = line[: self.cx], line[self.cx:]
        indent = before[: len(before) - len(before.lstrip(" \t"))]
        if self.spec is not None and self.spec.py and before.rstrip().endswith(":"):
            indent += "    "
        self.lines[self.cy] = before
        self.lines.insert(self.cy + 1, indent + after.lstrip(" \t"))
        self.cy += 1
        self.cx = self.want = len(indent)

    def backspace(self):
        line = self.lines[self.cy]
        if self.cx > 0:
            before = line[: self.cx]
            n = 1
            if before.strip(" ") == "" and "\t" not in before:
                n = (self.cx % 4) or 4
            self.snap("back")
            self.lines[self.cy] = line[: self.cx - n] + line[self.cx:]
            self.cx -= n
        elif self.cy > 0:
            self.snap("join")
            prev = self.lines[self.cy - 1]
            self.lines[self.cy - 1] = prev + line
            del self.lines[self.cy]
            self.cy -= 1
            self.cx = len(prev)
        self.want = self.cx

    def delete(self):
        line = self.lines[self.cy]
        if self.cx < len(line):
            self.snap("del")
            self.lines[self.cy] = line[: self.cx] + line[self.cx + 1:]
        elif self.cy < len(self.lines) - 1:
            self.snap("join")
            self.lines[self.cy] = line + self.lines[self.cy + 1]
            del self.lines[self.cy + 1]

    # -- movement
    def move(self, dy=0, dx=0):
        self.kind = None
        if dx:
            self.cx += dx
            if self.cx < 0:
                if self.cy > 0:
                    self.cy -= 1
                    self.cx = len(self.lines[self.cy])
                else:
                    self.cx = 0
            elif self.cx > len(self.lines[self.cy]):
                if self.cy < len(self.lines) - 1:
                    self.cy += 1
                    self.cx = 0
                else:
                    self.cx = len(self.lines[self.cy])
            self.want = self.cx
        if dy:
            self.cy = max(0, min(len(self.lines) - 1, self.cy + dy))
            self.cx = min(self.want, len(self.lines[self.cy]))

    def home(self):
        self.kind = None
        line = self.lines[self.cy]
        first = len(line) - len(line.lstrip(" \t"))
        self.cx = first if self.cx != first else 0
        self.want = self.cx

    def end(self):
        self.kind = None
        self.cx = self.want = len(self.lines[self.cy])

    def goto(self, line, col=0):
        self.kind = None
        self.cy = max(0, min(len(self.lines) - 1, line))
        self.cx = self.want = max(0, min(len(self.lines[self.cy]), col))

    def find(self, needle):
        if not needle:
            return False
        ci = needle == needle.lower()
        n = len(self.lines)
        for step in range(n + 1):
            i = (self.cy + step) % n
            hay = self.lines[i].lower() if ci else self.lines[i]
            start = self.cx + 1 if step == 0 else 0
            j = hay.find(needle.lower() if ci else needle, start)
            if j >= 0 and (step < n or j <= self.cx):
                self.goto(i, j)
                return True
        return False

    # -- drawing
    def vcol(self):
        return len(self.lines[self.cy][: self.cx].expandtabs(4))

    def fit(self, h, tw):
        if self.cy < self.top:
            self.top = self.cy
        elif self.cy >= self.top + h:
            self.top = self.cy - h + 1
        vx = self.vcol()
        if vx < self.left:
            self.left = vx
        elif vx >= self.left + tw:
            self.left = vx - tw + 1
        self.top = max(0, min(self.top, len(self.lines) - 1))

    @staticmethod
    def visual(line, attrs):
        if "\t" not in line:
            return line, attrs
        out, oa, col = [], [], 0
        for ch, a in zip(line, attrs):
            if ch == "\t":
                n = 4 - col % 4
                out.append(" " * n)
                oa.extend([a] * n)
                col += n
            else:
                out.append(ch)
                oa.append(a)
                col += 1
        return "".join(out), oa

    def draw(self, scr, y0, x0, h, w):
        g = len(str(len(self.lines)))
        gut = g + 1
        tw = max(1, w - gut)
        self.fit(h, tw)
        for r in range(h):
            i = self.top + r
            if i >= len(self.lines):
                break
            line = self.lines[i]
            put(scr, y0 + r, x0, "%*d " % (g, i + 1), A["lineno"])
            if self.spec is None or len(line) > 3000:
                attrs = [DEF] * len(line)
            else:
                attrs = highlight_line(line, self.spec, self.state_at(i))[0]
            text, at = self.visual(line, attrs)
            seg = text[self.left:self.left + tw]
            sat = at[self.left:self.left + tw]
            j = 0
            while j < len(seg):
                k = j
                while k < len(seg) and sat[k] == sat[j]:
                    k += 1
                put(scr, y0 + r, x0 + gut + j, seg[j:k], SYN[sat[j]])
                j = k
        return y0 + self.cy - self.top, x0 + gut + self.vcol() - self.left


# --------------------------------------------------------------------------- app
class App:
    def __init__(self, scr):
        self.scr = scr
        curses.raw()
        scr.keypad(True)
        scr.timeout(100)
        init_colors()
        self.root = Path.cwd().resolve()
        self.cwd = self.root
        self.config = load_config()
        self.client = None
        self.skills_on = []
        self.client = self.make_client()
        self.ed = Editor()
        self.focus = "editor"
        self.expanded = {str(self.root)}
        self.items = []
        self.tsel = self.ttop = 0
        self.term_log, self.chat_log = Log(), Log()
        self.term_in, self.chat_in = LineEdit(), LineEdit()
        self.q = queue.Queue()
        self.proc = None
        self.kill_reason = None
        self.chat_busy = False
        self.chat_cancel = threading.Event()
        self.last_answer = ""
        self.pending_models = None
        self.last_find = ""
        self.attachments = []
        self.attach_pending = 0
        self.pick_dir = None
        self.created = []
        self.auto_write = False
        self.pending_write = False
        self.workspace = self.root
        self.status, self.status_ts = "", 0.0
        self.running = True
        self.geo = {"th": 10, "ew": 40, "bh": 8, "tw": 20, "cw": 20}
        self.build_tree()
        self.term_log.add("dim", "dcaCode %s terminal ready." % __version__)
        self.term_log.add("dim", "Working directory: %s" % self.root)
        if not self.client:
            self.term_log.add("err", "API not configured. Set a key or DCACODE_API_PROXY_URL.")
        elif PROXY_URL:
            self.term_log.add("dim", "Using secured API proxy: %s" % PROXY_URL)
        self.chat_log.add("dim", "Chat ready. /help for commands, /file <question> attaches the open file.")

    # ---------------------------------------------------------------- helpers
    def make_client(self):
        key = effective_key(self.config)
        model = self.config.get("OPENROUTER_MODEL") or DEFAULT_MODEL
        if not key and not PROXY_URL:
            return None
        new = OpenRouter(key, model)
        if self.client is not None:  # keep the conversation when key/model change
            new.history = self.client.history
        new.extra_system = skills_prompt(self.root, self.skills_on)
        return new

    def set_status(self, msg):
        self.status, self.status_ts = msg, time.time()

    def rel(self, path):
        try:
            return str(Path(path).relative_to(self.root))
        except ValueError:
            return str(path)

    def resolve_inside(self, value):
        try:
            p = (self.root / os.path.expanduser(value.strip())).resolve()
            p.relative_to(self.root)
            return p
        except (ValueError, OSError, RuntimeError):
            self.set_status("Path must stay inside the project folder.")
            return None

    # ---------------------------------------------------------------- tree
    def build_tree(self):
        selected = self.items[self.tsel][0] if self.items and self.tsel < len(self.items) else None
        items = [(str(self.root), 0, True)]

        def walk(d, depth):
            try:
                kids = sorted(d.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            except OSError:
                return
            for p in kids[:500]:
                if p.name.startswith(".") or p.name in IGNORED:
                    continue
                isdir = p.is_dir()
                items.append((str(p), depth, isdir))
                if isdir and str(p) in self.expanded:
                    walk(p, depth + 1)

        walk(self.root, 1)
        self.items = items
        self.tsel = 0
        if selected:
            for i, it in enumerate(items):
                if it[0] == selected:
                    self.tsel = i
                    break

    def tree_key(self, k):
        n = len(self.items)
        page = max(1, self.geo["th"] - 1)
        if k == curses.KEY_UP:
            self.tsel = max(0, self.tsel - 1)
        elif k == curses.KEY_DOWN:
            self.tsel = min(n - 1, self.tsel + 1)
        elif k == curses.KEY_PPAGE:
            self.tsel = max(0, self.tsel - page)
        elif k == curses.KEY_NPAGE:
            self.tsel = min(n - 1, self.tsel + page)
        elif k == curses.KEY_HOME:
            self.tsel = 0
        elif k == curses.KEY_END:
            self.tsel = n - 1
        elif k in ("r", "R"):
            self.build_tree()
        elif k in (curses.KEY_RIGHT, curses.KEY_LEFT, "\n", "\r", " "):
            path, depth, isdir = self.items[self.tsel]
            if isdir:
                if k == curses.KEY_LEFT:
                    if path in self.expanded and depth > 0:
                        self.expanded.discard(path)
                    elif depth > 0:
                        parent = str(Path(path).parent)
                        for i, it in enumerate(self.items):
                            if it[0] == parent:
                                self.tsel = i
                                break
                elif path in self.expanded and k != curses.KEY_RIGHT and depth > 0:
                    self.expanded.discard(path)
                else:
                    self.expanded.add(path)
                self.build_tree()
            elif k != curses.KEY_LEFT:
                self.open_file(Path(path))
        top = self.ttop
        h = self.geo["th"] - 1
        self.tsel = max(0, min(self.tsel, len(self.items) - 1))
        if self.tsel < top:
            top = self.tsel
        elif self.tsel >= top + h:
            top = self.tsel - h + 1
        self.ttop = max(0, min(top, len(self.items) - 1))

    # ---------------------------------------------------------------- files
    def open_file(self, path, create=False):
        if self.ed.path == path and not create:
            self.focus = "editor"
            return
        if self.ed.dirty and not self.confirm("Discard unsaved changes in %s?" % (self.rel(self.ed.path) if self.ed.path else "buffer")):
            return
        if create and not path.exists():
            self.ed.load("", path)
            self.focus = "editor"
            self.set_status("New file (not saved yet): %s" % self.rel(path))
            return
        try:
            if path.stat().st_size > MAX_FILE:
                self.set_status("File too large to open (>1 MB).")
                return
            data = path.read_bytes()
            if b"\x00" in data[:8192]:
                self.set_status("Binary file, not opened.")
                return
            self.ed.load(data.decode("utf-8"), path)
        except UnicodeDecodeError:
            self.set_status("Cannot open: file is not UTF-8 text.")
            return
        except OSError as exc:
            self.set_status("Cannot open file: %s" % exc)
            return
        self.focus = "editor"
        self.set_status("Opened %s" % self.rel(path))

    def action_open_path(self):
        value = self.prompt("Open path (project-relative; new names create a file)")
        if not value:
            return
        path = self.resolve_inside(value)
        if path is None:
            return
        if path.is_dir():
            self.set_status("That is a folder.")
        else:
            self.open_file(path, create=True)

    def action_save(self):
        ed = self.ed
        if ed.path is None:
            value = self.prompt("Save as (project-relative path)")
            if not value:
                return False
            path = self.resolve_inside(value)
            if path is None:
                return False
            ed.set_path(path)
        try:
            ed.path.parent.mkdir(parents=True, exist_ok=True)
            with open(str(ed.path), "w", encoding="utf-8", newline="") as fh:
                fh.write(ed.text())
        except OSError as exc:
            self.set_status("Save failed: %s" % exc)
            return False
        ed.dirty = False
        self.set_status("Saved %s" % self.rel(ed.path))
        self.term_log.add("dim", "Saved: %s" % ed.path)
        self.build_tree()
        return True

    def action_run_file(self):
        ed = self.ed
        if ed.dirty or ed.path is None:
            if not self.action_save():
                return
        runner = RUNNERS.get(ed.path.suffix.lower())
        if not runner:
            self.set_status("F5 runs: %s. Use the terminal for other files." % ", ".join(sorted(RUNNERS)))
            return
        self.run_command(" ".join(shlex.quote(x) for x in runner + [str(ed.path)]))

    def action_goto(self):
        value = self.prompt("Go to line")
        if value and value.strip().isdigit():
            self.ed.goto(int(value) - 1)

    def action_find(self):
        value = self.prompt("Find (lowercase = ignore case)", self.last_find)
        if not value:
            return
        self.last_find = value
        if not self.ed.find(value):
            self.set_status("Not found: %s" % value)

    # ---------------------------------------------------------------- config / models
    def action_edit_env(self):
        key = self.prompt("OpenRouter API key (empty = keep current)", "", mask=True)
        if key is None:
            return
        model = self.prompt("Model ID", self.config.get("OPENROUTER_MODEL") or DEFAULT_MODEL)
        if model is None:
            return
        values = dict(self.config)
        if key.strip():
            if not validate_api_key(key.strip()):
                self.set_status("Invalid API key format; key was not saved.")
                return
            values["OPENROUTER_API_KEY"] = key.strip()
        values["OPENROUTER_MODEL"] = model.strip() or DEFAULT_MODEL
        try:
            path = save_config(values)
        except (OSError, ValueError) as exc:
            self.set_status("Cannot save settings: %s" % exc)
            return
        self.config = values
        self.client = self.make_client()
        self.set_status("API settings saved securely.")

    def action_models(self):
        if not self.client:
            self.set_status("Configure the API key first: Ctrl+E")
            return
        self.set_status("Fetching model catalog…")
        client = self.client

        def work():
            try:
                self.q.put(("models", client.models()))
            except Exception as exc:
                self.q.put(("status", "Model list error: %s" % exc))

        threading.Thread(target=work, daemon=True).start()

    def choose_model(self, models):
        current = self.client.model if self.client else ""
        items = [(m["id"], "%s — %s" % (m["id"], m["name"])) for m in models]
        model = self.choose("Choose model (current: %s)" % current, items)
        if not model:
            return
        self.config["OPENROUTER_MODEL"] = model
        try:
            save_config(self.config)
        except OSError as exc:
            self.set_status("Cannot save settings: %s" % exc)
        self.client = self.make_client()
        self.set_status("Model selected: %s" % model)

    # ---------------------------------------------------------------- terminal
    def run_command(self, cmd):
        cmd = cmd.strip()
        if not cmd:
            return
        log = self.term_log
        if cmd.startswith("!"):
            return self.run_interactive(cmd[1:].strip())
        log.add("user", "$ %s" % cmd)
        log.offset = 0
        if cmd == "clear":
            log.clear()
            return
        parts = cmd.split(None, 1)
        if parts[0] == "cd":
            target = Path(os.path.expanduser(parts[1].strip().strip("\"'"))) if len(parts) > 1 else Path.home()
            target = (self.cwd / target).resolve()
            if target.is_dir():
                self.cwd = target
                log.add("dim", "directory: %s" % target)
            else:
                log.add("err", "cd: no such directory: %s" % target)
            return
        if self.proc is not None:
            log.add("err", "A command is already running (Ctrl+C in this pane stops it).")
            return
        self.kill_reason = None
        self.proc = True  # reserved until the worker publishes the Popen object
        threading.Thread(target=self._run_worker, args=(cmd, str(self.cwd)), daemon=True).start()

    def _run_worker(self, cmd, cwd):
        try:
            proc = subprocess.Popen(
                cmd, shell=True, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL, universal_newlines=True, errors="replace", bufsize=1,
                start_new_session=(os.name == "posix"))
        except Exception as exc:
            self.q.put(("term", "Command failed: %s" % exc, True))
            self.q.put(("term_done", None))
            return
        self.proc = proc
        timer = threading.Timer(CMD_TIMEOUT, self.kill_proc, args=("timeout",))
        timer.daemon = True
        timer.start()
        try:
            for line in proc.stdout:
                self.q.put(("term", line.rstrip("\n"), False))
            rc = proc.wait()
        finally:
            timer.cancel()
        self.q.put(("term_done", rc))

    def kill_proc(self, reason="stopped"):
        proc = self.proc
        if proc is None or proc is True:
            return
        self.kill_reason = reason
        try:
            if os.name == "posix":
                os.killpg(proc.pid, signal.SIGTERM)
            else:
                proc.terminate()
        except (OSError, ProcessLookupError):
            pass

    def run_interactive(self, cmd):
        if not cmd:
            return
        self.term_log.add("user", "$ !%s" % cmd)
        curses.def_prog_mode()
        curses.endwin()
        try:
            subprocess.call(cmd, shell=True, cwd=str(self.cwd))
            try:
                input("\n[dcaCode] Press Enter to return… ")
            except (EOFError, KeyboardInterrupt):
                pass
        except KeyboardInterrupt:
            pass
        finally:
            curses.reset_prog_mode()
            self.scr.clear()
            self.scr.refresh()
        self.build_tree()

    # ---------------------------------------------------------------- chat
    def user_path(self, arg):
        arg = arg.strip().strip("\"'")
        p = Path(os.path.expanduser(arg))
        return p if p.is_absolute() else self.root / p

    def attach(self, path):
        if len(self.attachments) + self.attach_pending >= 8:
            self.chat_log.add("err", "At most 8 attachments per message (/detach clears them).")
            return
        self.attach_pending += 1
        name = Path(path).name or str(path)
        self.set_status("Reading %s…" % name)

        def work():
            try:
                self.q.put(("attach", load_attachment(path), None))
            except Exception as exc:
                self.q.put(("attach", None, str(exc)))

        threading.Thread(target=work, daemon=True).start()

    @staticmethod
    def _pick_label(p):
        if p.is_dir():
            return p.name + "/"
        try:
            return "%s  (%s)" % (p.name, human(p.stat().st_size))
        except OSError:
            return p.name

    def action_attach(self):
        """File picker: browse folders, Enter attaches a file; '[ attach this folder ]' sends the folder."""
        cur = self.pick_dir if self.pick_dir and self.pick_dir.is_dir() else self.root
        while True:
            try:
                kids = sorted(cur.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
            except OSError as exc:
                self.set_status("Cannot read %s: %s" % (cur, exc))
                cur = cur.parent
                continue
            items = [("@here", "[ attach this folder ]"), ("@up", "../  (up)")]
            for p in kids[:3000]:
                if not p.name.startswith("."):
                    items.append((("d:" if p.is_dir() else "f:") + p.name, self._pick_label(p)))
            title = "Attach from %s  [%d pending] - Esc closes" % (cur, len(self.attachments) + self.attach_pending)
            key = self.choose(title, items)
            if not key:
                break
            if key == "@here":
                self.attach(cur)
            elif key == "@up":
                cur = cur.parent
            elif key.startswith("d:"):
                cur = cur / key[2:]
            elif key.startswith("f:"):
                self.attach(cur / key[2:])
            else:  # a typed or pasted path
                p = dropped_path(key) or self.user_path(key)
                if p.is_dir():
                    cur = p
                elif p.exists():
                    self.attach(p)
                else:
                    self.set_status("No such path: %s" % key)
        self.pick_dir = cur

    def chat_submit(self, text):
        text = text.strip()
        if not text:
            return
        dropped = dropped_path(text)
        if dropped is not None:  # a path pasted / dropped into the chat box
            return self.attach(dropped)
        if not text.startswith("/"):
            return self.send_ai(text, text)
        cmd, _, rest = text.partition(" ")
        rest = rest.strip()
        log = self.chat_log
        if cmd == "/clear":
            log.clear()
            self.attachments = []
            if self.client:
                self.client.reset()
            log.add("dim", "Conversation cleared.")
        elif cmd == "/help":
            for line in CHAT_HELP:
                log.add("dim", line)
        elif cmd == "/apply":
            self.chat_apply(rest)
        elif cmd == "/file":
            if self.ed.path is None and self.ed.is_blank():
                log.add("err", "No file is open.")
                return
            body = self.ed.text()[:MAX_ATTACH]
            name = self.rel(self.ed.path) if self.ed.path else "buffer"
            f = fence_for(body)
            self.attachments.append({"kind": "file", "name": name, "size": len(body),
                                     "text": "Attached file: %s\n%s\n%s\n%s" % (name, f, body, f)})
            self.send_ai(rest or "Explain this file.", rest or "explain this file")
        elif cmd == "/attach":
            if rest:
                self.attach(self.user_path(rest))
            else:
                self.action_attach()
        elif cmd == "/detach":
            self.attachments = []
            log.add("dim", "Attachments cleared.")
        elif cmd == "/skill":
            self.skill_cmd(rest)
        elif cmd == "/new":
            self.new_cmd(rest)
        elif cmd == "/project":
            self.project_cmd(rest)
        elif cmd == "/write":
            self.chat_write()
        elif cmd == "/share":
            self.share_cmd(rest)
        else:
            log.add("err", "Unknown command. Try /help")

    def send_ai(self, prompt, shown):
        if not self.client:
            self.set_status("API key missing. Press Ctrl+E.")
            self.auto_write = False
            return
        if self.chat_busy:
            self.set_status("Wait for the current answer (Ctrl+C cancels).")
            return
        if self.attach_pending:
            self.set_status("Still reading attachments, try again in a moment.")
            return
        self.refresh_skills()
        content = build_content(prompt, self.attachments)
        names = ", ".join(a["name"] for a in self.attachments)
        self.attachments = []
        self.chat_log.offset = 0
        self.chat_log.add("user", "You: %s%s" % (shown, "  [+ %s]" % names if names else ""))
        self.chat_log.entries.append(["ai", "AI: "])
        self.chat_busy = True
        self.chat_cancel = threading.Event()
        client, cancel = self.client, self.chat_cancel

        def work():
            try:
                ans = client.chat(content, lambda d: self.q.put(("chat_delta", d)), cancel)
                self.q.put(("chat_done", ans))
            except Cancelled:
                self.q.put(("chat_done", None))
            except Exception as exc:
                self.q.put(("chat_err", str(exc)))

        threading.Thread(target=work, daemon=True).start()

    # -- skills
    def refresh_skills(self):
        known = list_skills(self.root)
        self.skills_on = [n for n in self.skills_on if n in known]
        if self.client:
            self.client.extra_system = skills_prompt(self.root, self.skills_on)

    def skill_cmd(self, rest):
        parts = rest.split(None, 1)
        sub = parts[0] if parts else "list"
        arg = parts[1].strip() if len(parts) > 1 else ""
        skills = list_skills(self.root)
        log = self.chat_log
        if sub == "list":
            for n, sk in sorted(skills.items()):
                on = n in self.skills_on
                log.add("ok" if on else "dim", "%s %s [%s] %s" % ("[x]" if on else "[ ]", n, sk["source"], sk["desc"]))
            log.add("dim", "/skill use <name> · off [name] · show <name> · new <name>   (F9 = picker)")
        elif sub == "use":
            if arg not in skills:
                log.add("err", "No skill '%s'. /skill lists them." % arg)
            elif arg not in self.skills_on:
                self.skills_on.append(arg)
            self.refresh_skills()
            log.add("ok", "Active skills: %s" % (", ".join(self.skills_on) or "none"))
        elif sub == "off":
            self.skills_on = [n for n in self.skills_on if arg and n != arg]
            self.refresh_skills()
            log.add("dim", "Active skills: %s" % (", ".join(self.skills_on) or "none"))
        elif sub == "show":
            if arg in skills:
                log.add("dim", skills[arg]["text"][:1500])
            else:
                log.add("err", "No skill '%s'." % arg)
        elif sub == "new":
            if not valid_skill_name(arg):
                log.add("err", "Usage: /skill new <name>  (letters, digits, . _ -)")
                return
            path = self.root / ".dcacode" / "skills" / ("%s.md" % arg)
            try:
                if not path.exists():
                    path.parent.mkdir(parents=True, exist_ok=True)
                    path.write_text(skill_template(arg), encoding="utf-8")
            except OSError as exc:
                log.add("err", "Cannot create skill: %s" % exc)
                return
            self.open_file(path)
            log.add("dim", "Edit the skill, Ctrl+S, then /skill use %s" % arg)
        else:
            log.add("err", "Usage: /skill [list|use|off|show|new] <name>")

    def action_skills(self):
        while True:
            skills = list_skills(self.root)
            items = [(n, "%s %s [%s] %s" % ("[x]" if n in self.skills_on else "[ ]", n, sk["source"], sk["desc"]))
                     for n, sk in sorted(skills.items())]
            n = self.choose("Skills - Enter toggles, Esc closes", items)
            if not n or n not in skills:
                break
            if n in self.skills_on:
                self.skills_on.remove(n)
            else:
                self.skills_on.append(n)
        self.refresh_skills()
        self.set_status("Active skills: %s" % (", ".join(self.skills_on) or "none"))

    # -- projects
    def set_root(self, path):
        self.root = Path(path).resolve()
        self.cwd = self.root
        self.expanded = {str(self.root)}
        self.tsel = self.ttop = 0
        self.ed.load("", None)
        self.attachments = []
        self.created = []
        self.build_tree()
        self.refresh_skills()
        self.term_log.add("dim", "Project: %s" % self.root)
        self.set_status("Project: %s" % self.root)

    def project_cmd(self, rest):
        if not rest:
            self.chat_log.add("dim", "Project: %s" % self.root)
            return
        p = self.user_path(rest)
        if not p.is_dir():
            self.chat_log.add("err", "Not a folder: %s" % p)
        elif not (self.ed.dirty and not self.confirm("Discard unsaved changes and switch project?")):
            self.set_root(p)

    def new_project(self, name, template, desc=""):
        if self.ed.dirty and not self.confirm("Discard unsaved changes and switch project?"):
            return
        try:
            path = create_project(self.workspace, name, template)
        except (ValueError, OSError) as exc:
            self.chat_log.add("err", "New project: %s" % exc)
            self.set_status("New project failed: %s" % exc)
            return
        self.set_root(path)
        if self.client:
            self.client.reset()
        self.chat_log.add("ok", "Created project %s (%s template)." % (name, template))
        if desc:
            self.auto_write = True
            self.send_ai("Create the project files for: %s\nUse file=path code blocks with complete files." % desc,
                         "new project: %s" % desc)

    def new_cmd(self, rest):
        toks = rest.split()
        if not toks:
            return self.action_new_project()
        name, template, desc = toks[0], "python", ""
        if "ask" in toks[1:]:
            i = toks.index("ask", 1)
            desc = " ".join(toks[i + 1:])
            template = toks[1] if i > 1 else "empty"
        elif len(toks) > 1:
            template = toks[1]
        self.new_project(name, template, desc)

    def action_new_project(self):
        name = self.prompt("New project name (created in %s)" % self.workspace)
        if not name or not name.strip():
            return
        items = [(t, "%s - %s" % (t, TEMPLATE_INFO[t])) for t in TEMPLATES]
        template = self.choose("Template", items)
        if template not in TEMPLATES:
            return
        desc = self.prompt("Describe the project for the AI (empty = skip)", "") or ""
        self.new_project(name.strip(), template, desc.strip())

    # -- AI-created files and sharing
    def chat_write(self):
        files = extract_files(self.last_answer)
        if not files:
            self.chat_log.add("err", "The last answer has no file blocks (```lang file=path).")
            return
        plan, lines = [], []
        for rel, content in files:
            p = self.resolve_inside(rel)
            if p is None or p.is_dir() or len(content) > 1000000:
                lines.append("skipped   %s" % rel)
                continue
            plan.append((rel, p, content))
            lines.append("%-9s %s  (%d B)" % ("overwrite" if p.exists() else "new", rel, len(content.encode("utf-8"))))
        if not plan:
            self.chat_log.add("err", "Nothing to write (unsafe paths skipped).")
            return
        if not self.confirm("Write %d file(s) into %s?" % (len(plan), self.root.name), lines):
            return
        done, note = [], ""
        for rel, p, content in plan:
            try:
                p.parent.mkdir(parents=True, exist_ok=True)
                with open(str(p), "w", encoding="utf-8", newline="") as fh:
                    fh.write(content)
            except OSError as exc:
                self.chat_log.add("err", "Write failed for %s: %s" % (rel, exc))
                continue
            done.append(rel)
            if rel not in self.created:
                self.created.append(rel)
            if self.ed.path == p:
                if self.ed.dirty:
                    note = " (the editor still has your unsaved copy of %s)" % rel
                else:
                    cy, cx = self.ed.cy, self.ed.cx
                    self.ed.load(content, p)
                    self.ed.goto(cy, cx)
        self.build_tree()
        if done:
            self.chat_log.add("ok", "Wrote %d file(s): %s%s" % (len(done), ", ".join(done)[:150], note))
            self.set_status("Wrote %d file(s). /share created zips them." % len(done))

    def share_cmd(self, rest):
        only = None
        if rest.strip() == "created":
            if not self.created:
                self.chat_log.add("err", "No AI-created files in this session yet.")
                return
            only = list(self.created)
        try:
            out, n, size = make_zip(self.root, self.root.name, only)
        except (ValueError, OSError) as exc:
            self.chat_log.add("err", "Share failed: %s" % exc)
            return
        self.build_tree()
        self.chat_log.add("ok", "Shared %d file(s), %d KB: %s" % (n, max(1, size // 1024), self.rel(out)))
        self.chat_log.add("dim", "Full path: %s (secrets such as api.env are never included)" % out)
        self.set_status("Shared: %s" % out)

    def chat_apply(self, arg):
        blocks = re.findall(r"```[^\n]*\n(.*?)```", self.last_answer, re.S)
        if not blocks:
            self.chat_log.add("err", "No code block in the last answer.")
            return
        idx = int(arg) - 1 if arg.isdigit() else len(blocks) - 1
        if not 0 <= idx < len(blocks):
            self.chat_log.add("err", "Block %s not found (%d available)." % (arg, len(blocks)))
            return
        if self.confirm("Replace the editor content with code block %d?" % (idx + 1)):
            self.ed.replace_all(blocks[idx].rstrip("\n"))
            self.set_status("Applied block %d. Review, then Ctrl+S (Ctrl+Z undoes)." % (idx + 1))

    # ---------------------------------------------------------------- events
    def pump(self):
        changed = False
        while True:
            try:
                ev = self.q.get_nowait()
            except queue.Empty:
                break
            changed = True
            kind = ev[0]
            if kind == "term":
                self.term_log.add("err" if ev[2] else "def", ev[1])
            elif kind == "term_done":
                rc = ev[1]
                reason = self.kill_reason
                self.proc = None
                if reason == "timeout":
                    self.term_log.add("err", "[timed out after %ds]" % CMD_TIMEOUT)
                elif reason:
                    self.term_log.add("err", "[stopped]")
                elif rc is not None:
                    self.term_log.add("dim" if rc == 0 else "err", "[exit %s]" % rc)
                self.build_tree()
            elif kind == "chat_delta":
                if self.chat_log.entries and self.chat_log.entries[-1][0] == "ai":
                    self.chat_log.entries[-1][1] += clean(ev[1])
            elif kind == "chat_done":
                self.chat_busy = False
                if ev[1] is None:
                    self.chat_log.add("dim", "[cancelled]")
                else:
                    self.last_answer = ev[1]
                    files = extract_files(ev[1])
                    if files:
                        self.chat_log.add("ok", "AI proposed %d file(s): %s - type /write to create them."
                                          % (len(files), ", ".join(f[0] for f in files)[:120]))
                        if self.auto_write:
                            self.pending_write = True
                    self.set_status("AI response received.")
                self.auto_write = self.auto_write and self.pending_write
            elif kind == "chat_err":
                self.chat_busy = False
                self.auto_write = False
                if self.chat_log.entries and self.chat_log.entries[-1] == ["ai", "AI: "]:
                    self.chat_log.entries.pop()
                self.chat_log.add("err", "OpenRouter error: %s" % ev[1])
            elif kind == "attach":
                self.attach_pending = max(0, self.attach_pending - 1)
                if ev[2]:
                    self.chat_log.add("err", "Cannot attach: %s" % ev[2])
                    self.set_status("Cannot attach: %s" % ev[2])
                else:
                    att = ev[1]
                    self.attachments.append(att)
                    extra = ", %d files" % att["count"] if att["kind"] == "folder" else ""
                    note = " - %s" % att["note"] if att.get("note") else ""
                    self.chat_log.add("ok", "Attached %s %s (%s%s)%s. Sent with your next message."
                                      % (att["kind"], att["name"], human(att["size"]), extra, note))
                    self.set_status("Attached %s" % att["name"])
            elif kind == "models":
                self.pending_models = ev[1]
            elif kind == "status":
                self.set_status(ev[1])
        if self.status and time.time() - self.status_ts > 8:
            self.status = ""
            changed = True
        return changed

    # ---------------------------------------------------------------- modals
    def box(self, title, w, h):
        H, W = self.scr.getmaxyx()
        w, h = min(w, W - 2), min(h, H - 2)
        y, x = (H - h) // 2, (W - w) // 2
        for r in range(h):
            put(self.scr, y + r, x, " " * w, A["box"])
        put(self.scr, y, x, "┌" + "─" * (w - 2) + "┐", A["headf"])
        put(self.scr, y, x + 2, " %s " % title[: w - 6], A["headf"])
        for r in range(1, h - 1):
            put(self.scr, y + r, x, "│", A["headf"])
            put(self.scr, y + r, x + w - 1, "│", A["headf"])
        put(self.scr, y + h - 1, x, "└" + "─" * (w - 2) + "┘", A["headf"])
        return y, x, w, h

    def paste_or_key(self, keys, edit):
        """Feed keys to a LineEdit; returns 'enter'/'esc' or None."""
        if len(keys) > 1 and all(isinstance(k, str) and (k.isprintable() or k in "\r\n\t") for k in keys):
            edit.paste("".join(keys))
            return None
        for k in keys:
            r = edit.key(k)
            if r in ("enter", "esc"):
                return r
        return None

    def prompt(self, title, initial="", mask=False):
        edit = LineEdit(initial, mask)
        while True:
            self.pump()
            self.draw(refresh=False)
            y, x, w, h = self.box(title, 72, 5)
            cx = edit.draw(self.scr, y + 2, x + 2, w - 4)
            put(self.scr, y + 3, x + 2, "Enter = OK · Esc = cancel", A["dim"])
            self.scr.move(y + 2, min(cx, x + w - 2))
            self.scr.refresh()
            r = self.paste_or_key(self.read_keys(), edit)
            if r == "enter":
                return edit.text
            if r == "esc":
                return None

    def confirm(self, message, lines=()):
        lines = list(lines)
        shown = lines[:12] + (["… %d more" % (len(lines) - 12)] if len(lines) > 12 else [])
        while True:
            self.pump()
            self.draw(refresh=False)
            wid = max([40, len(message) + 6] + [len(t) + 6 for t in shown])
            y, x, w, h = self.box("Confirm", wid, 5 + len(shown))
            put(self.scr, y + 1, x + 2, message[: w - 4])
            for r, t in enumerate(shown):
                put(self.scr, y + 2 + r, x + 2, t[: w - 4], A["dim"])
            put(self.scr, y + h - 2, x + 2, "y = yes · n / Esc = no", A["dim"])
            self.scr.refresh()
            for k in self.read_keys():
                if isinstance(k, str):
                    if k in ("y", "Y", "e", "E"):
                        return True
                    if k in ("n", "N", "\x1b", "h", "H"):
                        return False

    def choose(self, title, items):
        flt = LineEdit()
        sel = top = 0
        while True:
            q = flt.text.lower()
            shown = [it for it in items if q in it[1].lower()]
            self.pump()
            self.draw(refresh=False)
            H, W = self.scr.getmaxyx()
            y, x, w, h = self.box(title, 90, min(H - 4, 22))
            cx = flt.draw(self.scr, y + 1, x + 2, w - 4, "filter: ")
            rows = h - 4
            sel = max(0, min(sel, len(shown) - 1))
            if sel < top:
                top = sel
            elif sel >= top + rows:
                top = sel - rows + 1
            for r, it in enumerate(shown[top:top + rows]):
                put(self.scr, y + 2 + r, x + 2, it[1][: w - 4].ljust(w - 4),
                    A["sel"] if top + r == sel else A["def"])
            put(self.scr, y + h - 2, x + 2,
                ("%d matches · Up/Down · Enter = use · Esc = cancel" % len(shown))[: w - 4], A["dim"])
            self.scr.move(y + 1, min(cx, x + w - 2))
            self.scr.refresh()
            for k in self.read_keys():
                if k == curses.KEY_UP:
                    sel -= 1
                elif k == curses.KEY_DOWN:
                    sel += 1
                elif k == curses.KEY_PPAGE:
                    sel -= rows
                elif k == curses.KEY_NPAGE:
                    sel += rows
                elif k in ("\n", "\r"):
                    if shown:
                        return shown[sel][0]
                    return flt.text.strip() or None
                elif k == "\x1b":
                    return None
                else:
                    flt.key(k)
                    sel = top = 0

    def show_help(self):
        while True:
            self.draw(refresh=False)
            y, x, w, h = self.box("dcaCode %s — keys (any key closes)" % __version__, 78, len(HELP) + 4)
            for r, line in enumerate(HELP):
                put(self.scr, y + 1 + r, x + 2, line[: w - 4])
            self.scr.refresh()
            if self.read_keys():
                return

    # ---------------------------------------------------------------- drawing
    def header(self, y, x, w, text, focused):
        put(self.scr, y, x, (" " + text).ljust(w)[:w], A["headf"] if focused else A["head"])

    def draw(self, refresh=True):
        scr = self.scr
        scr.erase()
        H, W = scr.getmaxyx()
        if H < 16 or W < 60:
            put(scr, 0, 0, "Terminal too small (need 60x16).")
            if refresh:
                scr.refresh()
            return
        bh = max(8, min(H // 3, 14))
        th = H - 2 - bh
        sw = min(max(18, W // 4), 40)
        ew = W - sw - 1
        tw = W // 2
        cw = W - tw - 1
        self.geo = {"th": th, "ew": ew, "bh": bh, "tw": tw, "cw": cw}
        ed = self.ed
        name = self.rel(ed.path) if ed.path else "[scratch]"
        title = " dcaCode %s · %s%s" % (__version__, name, " ●" if ed.dirty else "")
        right = "F1 help · %s " % ((self.client.model if self.client else "no API key"))
        put(scr, 0, 0, title.ljust(W), A["title"])
        put(scr, 0, max(len(title) + 1, W - len(right)), right[: W - len(title) - 1], A["title"])
        cursor = None

        # tree
        self.header(1, 0, sw, "PROJECT FILES", self.focus == "tree")
        for r in range(th - 1):
            i = self.ttop + r
            if i >= len(self.items):
                break
            path, depth, isdir = self.items[i]
            mark = ("▾ " if path in self.expanded else "▸ ") if isdir else "  "
            label = (Path(path).name if depth else self.root.name + "/")
            text = ("  " * max(0, depth - 1) + mark + label)[: sw].ljust(sw)
            attr = A["dir"] if isdir else A["def"]
            if i == self.tsel:
                attr = A["sel"] if self.focus == "tree" else A["sel"] | curses.A_DIM
            put(scr, 2 + r, 0, text, attr)
        for r in range(1, th + 1):
            put(scr, r, sw, "│", A["sep"])

        # editor
        self.header(1, sw + 1, ew, "MONACO-STYLE EDITOR  Ctrl+S save · F5 run · Ctrl+F find", self.focus == "editor")
        if ed.is_blank():
            for r, line in enumerate(("Select a file in the tree (Enter),", "press Ctrl+O to open or create one,",
                                      "or just start typing in this scratch buffer.")):
                put(scr, 3 + r, sw + 3, line, A["dim"])
        ecur = ed.draw(scr, 2, sw + 1, th - 1, ew)
        if self.focus == "editor":
            cursor = ecur

        # bottom panes
        by = 1 + th
        for r in range(bh):
            put(scr, by + r, tw, "│", A["sep"])
        running = " (running)" if self.proc is not None else ""
        self.header(by, 0, tw, "TERMINAL  %s%s" % (str(self.cwd)[-(tw - 24):], running), self.focus == "term")
        busy = " (thinking…)" if self.chat_busy else ""
        extra = ""
        if self.attachments or self.attach_pending:
            extra += " · %d attached%s" % (len(self.attachments), "+" if self.attach_pending else "")
        if self.skills_on:
            extra += " · skills: %s" % ",".join(self.skills_on)
        self.header(by, tw + 1, cw, "AI CHAT%s%s" % (extra, busy), self.focus == "chat")
        for log, x0, w in ((self.term_log, 0, tw), (self.chat_log, tw + 1, cw)):
            for r, (style, text) in enumerate(log.tail(w, bh - 2)):
                put(scr, by + 1 + r, x0, text, A.get(style, A["def"]))
        tcur = self.term_in.draw(scr, by + bh - 1, 0, tw, "$ ")
        ccur = self.chat_in.draw(scr, by + bh - 1, tw + 1, cw, "> ")
        if self.focus == "term":
            cursor = (by + bh - 1, tcur)
        elif self.focus == "chat":
            cursor = (by + bh - 1, ccur)

        # status
        msg = self.status or "Ctrl+S save · Ctrl+O open · F5 run · F6 next pane · Ctrl+←→↑↓ panels · Ctrl+E API · F1 help"
        put(scr, H - 1, 0, (" " + msg).ljust(W), A["status"])

        try:
            curses.curs_set(1 if cursor else 0)
        except curses.error:
            pass
        if cursor:
            try:
                scr.move(min(cursor[0], H - 1), min(cursor[1], W - 1))
            except curses.error:
                pass
        if refresh:
            scr.refresh()

    # ---------------------------------------------------------------- input
    def read_keys(self):
        self.scr.timeout(100)
        try:
            k = self.scr.get_wch()
        except curses.error:
            return []
        keys = [k]
        self.scr.nodelay(True)
        try:
            while len(keys) < 5000:
                try:
                    keys.append(self.scr.get_wch())
                except curses.error:
                    break
        finally:
            self.scr.timeout(100)
        return keys

    def handle_keys(self, keys):
        if len(keys) >= 4 and all(isinstance(k, str) and (k.isprintable() or k in "\r\n\t") for k in keys):
            text = "".join(keys).replace("\r\n", "\n").replace("\r", "\n")
            if self.focus == "editor":
                self.ed.insert_text(text)
            elif self.focus == "term":
                self.term_in.paste(text)
            elif self.focus == "chat":
                self.chat_in.paste(text)
            return
        for k in keys:
            self.handle_key(k)

    def cycle_focus(self):
        order = ["editor", "term", "chat", "tree"]
        self.focus = order[(order.index(self.focus) + 1) % len(order)]

    def switch_panel(self, direction):
        """Fast VS Code/Monaco-like panel navigation with Ctrl+Arrow."""
        targets = {
            "left": "tree",
            "right": "editor",
            "down": "term",
            "up": "chat",
        }
        target = targets.get(direction)
        if target:
            self.focus = target
            self.set_status("Panel: %s" % target.upper())

    def handle_key(self, k):
        if k == curses.KEY_RESIZE:
            self.scr.clear()
            return
        if k == curses.KEY_F1:
            return self.show_help()
        if k == curses.KEY_F2:
            return self.build_tree()
        if k == curses.KEY_F5:
            return self.action_run_file()
        if k == curses.KEY_F6:
            return self.cycle_focus()

        # Many terminals expose modified arrows as KEY_CLEFT/KEY_CRIGHT etc.
        # Keep plain arrows for editing/tree navigation and use Ctrl+Arrow for panels.
        ctrl_arrows = {
            getattr(curses, "KEY_CLEFT", -10001): "left",
            getattr(curses, "KEY_CRIGHT", -10002): "right",
            getattr(curses, "KEY_CUP", -10003): "up",
            getattr(curses, "KEY_CDOWN", -10004): "down",
        }
        if isinstance(k, int) and k in ctrl_arrows:
            return self.switch_panel(ctrl_arrows[k])
        if k == curses.KEY_F7:
            return self.action_attach()
        if k == curses.KEY_F8:
            return self.action_new_project()
        if k == curses.KEY_F9:
            return self.action_skills()
        if isinstance(k, str):
            table = {"\x13": self.action_save, "\x0f": self.action_open_path,
                     "\x05": self.action_edit_env, "\x0c": self.action_models,
                     "\x11": self.action_quit, "\x06": self.action_find, "\x07": self.action_goto}
            if k in table:
                return table[k]()
            if k == "\x03":
                return self.action_interrupt()
            if k == "\x1b" and self.focus != "editor":
                self.focus = "editor"
                return
        if self.focus == "tree":
            self.tree_key(k)
        elif self.focus == "editor":
            self.editor_key(k)
        elif self.focus == "term":
            self.pane_key(k, self.term_in, self.term_log, self.geo["tw"], self.run_command)
        else:
            self.pane_key(k, self.chat_in, self.chat_log, self.geo["cw"], self.chat_submit)

    def action_interrupt(self):
        if self.focus == "term" and self.proc is not None:
            self.kill_proc("stopped")
        elif self.chat_busy:
            self.chat_cancel.set()
        else:
            self.set_status("Ctrl+C does nothing here. Use Ctrl+Q to quit.")

    def action_quit(self):
        if self.ed.dirty and not self.confirm("Unsaved changes. Quit anyway?"):
            return
        self.kill_proc("stopped")
        self.running = False

    def pane_key(self, k, edit, log, width, submit):
        rows = self.geo["bh"] - 2
        if k == curses.KEY_PPAGE:
            log.scroll(rows - 1, width, rows)
        elif k == curses.KEY_NPAGE:
            log.scroll(-(rows - 1), width, rows)
        else:
            r = edit.key(k)
            if r == "enter":
                text = edit.text
                edit.remember()
                edit.text, edit.pos = "", 0
                submit(text)
            elif r == "tab":
                self.cycle_focus()

    def editor_key(self, k):
        ed = self.ed
        page = max(1, self.geo["th"] - 2)
        if isinstance(k, int):
            if k == curses.KEY_UP:
                ed.move(dy=-1)
            elif k == curses.KEY_DOWN:
                ed.move(dy=1)
            elif k == curses.KEY_LEFT:
                ed.move(dx=-1)
            elif k == curses.KEY_RIGHT:
                ed.move(dx=1)
            elif k == curses.KEY_HOME:
                ed.home()
            elif k == curses.KEY_END:
                ed.end()
            elif k == curses.KEY_PPAGE:
                ed.move(dy=-page)
            elif k == curses.KEY_NPAGE:
                ed.move(dy=page)
            elif k == curses.KEY_BACKSPACE:
                ed.backspace()
            elif k == curses.KEY_DC:
                ed.delete()
            return
        if k in ("\n", "\r"):
            ed.newline()
        elif k in ("\x7f", "\b"):
            ed.backspace()
        elif k == "\t":
            ed.insert_text("    ")
        elif k == "\x1a":
            ed.do_undo()
        elif k == "\x19":
            ed.do_redo()
        elif k.isprintable():
            ed.insert_text(k)

    # ---------------------------------------------------------------- main loop
    def run(self):
        need = True
        while self.running:
            if self.pending_models is not None:
                models, self.pending_models = self.pending_models, None
                self.set_status("%d models loaded." % len(models))
                self.choose_model(models)
                need = True
            if self.pending_write:
                self.pending_write = False
                self.auto_write = False
                self.chat_write()
                need = True
            if self.pump():
                need = True
            if need:
                self.draw()
                need = False
            keys = self.read_keys()
            if keys:
                self.handle_keys(keys)
                need = True


def main():
    if curses is None:
        sys.stderr.write(
            "dcaCode needs Python's curses module (Linux/macOS/WSL).\n"
            "On native Windows run it inside WSL.\n")
        sys.exit(1)
    if not sys.stdin.isatty() or not sys.stdout.isatty():
        sys.stderr.write("dcaCode must be run in an interactive terminal.\n")
        sys.exit(1)
    locale.setlocale(locale.LC_ALL, "")
    os.environ.setdefault("ESCDELAY", "25")
    curses.wrapper(lambda scr: App(scr).run())


if __name__ == "__main__":
    main()
