"""Tiny line-based syntax highlighter (standard library only)."""
import os

DEF, KW, STR, CMT, NUM = range(5)


class Spec:
    def __init__(self, kw=(), lc=(), block=None, quotes="", triple=False, py=False):
        self.kw = frozenset(kw)
        self.lc = tuple(lc)
        self.block = block
        self.quotes = quotes
        self.triple = triple
        self.py = py


PY_KW = ("False None True and as assert async await break class continue def del elif else "
         "except finally for from global if import in is lambda nonlocal not or pass raise "
         "return try while with yield").split()
SH_KW = ("if then else elif fi for while until do done case esac in function select export "
         "local return exit echo cd source alias unset readonly shift break continue set").split()
C_KW = ("break case catch class const continue default do else enum export extends false final "
        "finally for function if implements import in instanceof interface let new null package "
        "private protected public return static struct super switch this throw true try typedef "
        "typeof undefined var void while yield async await fn func go defer impl let mut pub use "
        "mod match int long char float double bool string namespace using").split()

PY = Spec(PY_KW, ("#",), None, "\"'", True, True)
SH = Spec(SH_KW, ("#",), None, "\"'", False)
CLIKE = Spec(C_KW, ("//",), ("/*", "*/"), "\"'`", False)
RUST = Spec(C_KW, ("//",), ("/*", "*/"), "\"", False)
JSON = Spec(("true", "false", "null"), (), None, "\"", False)
CONF = Spec((), ("#",), None, "\"'", False)
SQL = Spec(("select from where insert into update delete create table drop alter join on and or "
            "not null values set order by group limit").split(), ("--",), ("/*", "*/"), "\"'", False)

EXT = {
    ".py": PY, ".pyw": PY,
    ".sh": SH, ".bash": SH, ".zsh": SH,
    ".js": CLIKE, ".mjs": CLIKE, ".jsx": CLIKE, ".ts": CLIKE, ".tsx": CLIKE, ".java": CLIKE,
    ".c": CLIKE, ".h": CLIKE, ".cpp": CLIKE, ".hpp": CLIKE, ".cc": CLIKE, ".go": CLIKE,
    ".cs": CLIKE, ".kt": CLIKE, ".swift": CLIKE, ".php": CLIKE, ".rs": RUST,
    ".json": JSON,
    ".toml": CONF, ".ini": CONF, ".cfg": CONF, ".conf": CONF, ".yml": CONF, ".yaml": CONF,
    ".env": CONF, ".example": CONF,
    ".sql": SQL,
}


def language_for(path):
    if path is None:
        return None
    return EXT.get(os.path.splitext(str(path))[1].lower())


def _fill(attrs, a, b, value):
    b = min(b, len(attrs))
    if b > a:
        attrs[a:b] = [value] * (b - a)


def highlight_line(line, spec, state):
    """Return (attrs, new_state). state is the closing token of an open
    multi-line construct (triple quote or block comment) or None."""
    n = len(line)
    attrs = [DEF] * n
    if spec is None:
        return attrs, None
    i = 0
    if state:
        style = CMT if state == "*/" else STR
        j = line.find(state)
        if j < 0:
            return [style] * n, state
        i = j + len(state)
        _fill(attrs, 0, i, style)
        state = None
    while i < n:
        c = line[i]
        hit = False
        for lc in spec.lc:
            if line.startswith(lc, i):
                _fill(attrs, i, n, CMT)
                return attrs, None
        if spec.block and line.startswith(spec.block[0], i):
            j = line.find(spec.block[1], i + len(spec.block[0]))
            if j < 0:
                _fill(attrs, i, n, CMT)
                return attrs, spec.block[1]
            j += len(spec.block[1])
            _fill(attrs, i, j, CMT)
            i = j
            continue
        if c in spec.quotes:
            if spec.triple and line.startswith(c * 3, i):
                tok = c * 3
                j = line.find(tok, i + 3)
                if j < 0:
                    _fill(attrs, i, n, STR)
                    return attrs, tok
                _fill(attrs, i, j + 3, STR)
                i = j + 3
                continue
            j = i + 1
            while j < n:
                if line[j] == "\\":
                    j += 2
                    continue
                if line[j] == c:
                    break
                j += 1
            end = min(j + 1, n)
            _fill(attrs, i, end, STR)
            i = end
            continue
        if c.isdigit() and (i == 0 or not (line[i - 1].isalnum() or line[i - 1] == "_")):
            j = i
            while j < n and (line[j].isalnum() or line[j] in "._"):
                j += 1
            _fill(attrs, i, j, NUM)
            i = j
            continue
        if c.isalpha() or c == "_":
            j = i
            while j < n and (line[j].isalnum() or line[j] == "_"):
                j += 1
            if line[i:j] in spec.kw:
                _fill(attrs, i, j, KW)
            i = j
            continue
        i += 1
    return attrs, None
