"""Configuration handling with safer API-key storage."""
import os
import stat
import tempfile
from pathlib import Path

DEFAULT_MODEL = "anthropic/claude-sonnet-4"
APP_DIR = Path.home() / ".config" / "dcacode"
USER_ENV = APP_DIR / "api.env"
PROJECT_ENV = Path("dca-gpe628") / "api.env"  # legacy only; never written by new versions


def load_env_file(path):
    values = {}
    try:
        if not path.is_file():
            return values
        # Refuse a group/world-readable key file on POSIX systems.
        if os.name != "nt" and (path.stat().st_mode & (stat.S_IRWXG | stat.S_IRWXO)):
            return values
        text = path.read_text(encoding="utf-8")
    except OSError:
        return values
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip().strip('"').strip("'")
    return values


def config_path():
    return USER_ENV


def load_config():
    # API keys are deliberately not loaded from project folders. This prevents
    # accidental commits, sharing, and project-local secret leakage.
    return load_env_file(USER_ENV)


def effective_key(values):
    # Environment variables are useful for CI/production and avoid writing a
    # production secret to disk.
    return os.environ.get("OPENROUTER_API_KEY", "").strip() or values.get("OPENROUTER_API_KEY", "").strip()


def validate_api_key(key):
    if not isinstance(key, str):
        return False
    key = key.strip()
    if len(key) < 16 or len(key) > 512 or any(c.isspace() for c in key):
        return False
    return True


def redact_key(key):
    key = (key or "").strip()
    if len(key) <= 8:
        return "[configured]" if key else "[missing]"
    return key[:4] + "…" + key[-4:]


def save_config(values):
    key = values.get("OPENROUTER_API_KEY", "").strip()
    if key and not validate_api_key(key):
        raise ValueError("Invalid API key format")
    USER_ENV.parent.mkdir(parents=True, exist_ok=True)
    text = "\n".join([
        "# dcaCode OpenRouter configuration (keep private)",
        "OPENROUTER_API_KEY=%s" % key,
        "OPENROUTER_MODEL=%s" % (values.get("OPENROUTER_MODEL") or DEFAULT_MODEL).strip(),
    ]) + "\n"
    fd, tmp = tempfile.mkstemp(prefix=".api.", dir=str(USER_ENV.parent), text=True)
    try:
        if os.name != "nt":
            os.fchmod(fd, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            fh.write(text)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(tmp, USER_ENV)
        if os.name != "nt":
            USER_ENV.chmod(0o600)
    except Exception:
        try: os.unlink(tmp)
        except OSError: pass
        raise
    return USER_ENV
