"""OpenRouter client built on urllib (no third-party packages)."""
import json
import urllib.error
import urllib.request
import time

API_URL = "https://openrouter.ai/api/v1/chat/completions"
MODELS_URL = "https://openrouter.ai/api/v1/models"
PROXY_URL = __import__("os").environ.get("DCACODE_API_PROXY_URL", "").strip().rstrip("/")
MAX_HISTORY = 40
MAX_PROMPT_CHARS = 240000
MAX_RESPONSE_BYTES = 8 * 1024 * 1024
MIN_REQUEST_INTERVAL = 0.25

SYSTEM_PROMPT = (
    "You are dcaCode, a helpful terminal coding assistant. "
    "Respond in the user's language. When asked to modify code, "
    "provide complete file contents in fenced code blocks and clearly label "
    "each file. Do not claim to have changed local files; this app applies "
    "edits only when the user explicitly applies and saves them.\n\n"
    "To create new files or replace whole files, put EACH file in its own fenced code "
    "block whose info string names the path, for example ```python file=src/app.py "
    "(relative paths only, never absolute, never '..'). Always give the complete file. "
    "The user decides whether to write them with /write, and can export them with /share. "
    "Code blocks without file= are treated as examples and are not written."
)


MEDIA_TYPES = ("image_url", "video_url", "input_audio")


def _has_images(content):
    return isinstance(content, list) and any(p.get("type") in MEDIA_TYPES for p in content)


def _strip_images(content):
    texts = [p.get("text", "") for p in content if p.get("type") == "text"]
    return "\n".join(texts) + "\n[media omitted from history]"


class ApiError(Exception):
    pass


class Cancelled(Exception):
    pass


def _http_error_message(exc):
    try:
        body = exc.read().decode("utf-8", "replace")
        msg = json.loads(body).get("error", {})
        if isinstance(msg, dict):
            msg = msg.get("message", body)
        return "HTTP %s: %s" % (exc.code, msg)
    except Exception:
        return "HTTP %s: %s" % (exc.code, exc.reason)


class OpenRouter:
    def __init__(self, api_key, model):
        self.api_key = api_key
        self.proxy_url = PROXY_URL
        self.model = model
        self.history = []
        self.extra_system = ""
        self._last_request = 0.0

    def reset(self):
        self.history = []

    def _throttle(self):
        wait = MIN_REQUEST_INTERVAL - (time.monotonic() - self._last_request)
        if wait > 0:
            time.sleep(wait)
        self._last_request = time.monotonic()

    def headers(self):
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "dcaCode/0.3",
        }
        if not self.proxy_url:
            headers["Authorization"] = "Bearer %s" % self.api_key
            headers["X-Title"] = "dcaCode"
            headers["X-OpenRouter-Title"] = "dcaCode"
        return headers

    def _chat_url(self):
        return self.proxy_url + "/api/chat/completions" if self.proxy_url else API_URL

    def _models_url(self):
        return self.proxy_url + "/api/models" if self.proxy_url else MODELS_URL

    def _messages(self):
        system = SYSTEM_PROMPT + ("\n\n" + self.extra_system if self.extra_system else "")
        hist = self.history[-MAX_HISTORY:]
        # Keep the media payload only for the most recent message that has media.
        last_img = max((i for i, m in enumerate(hist) if _has_images(m["content"])), default=-1)
        out = [{"role": "system", "content": system}]
        for i, m in enumerate(hist):
            c = m["content"]
            if isinstance(c, list) and i != last_img:
                c = _strip_images(c)
            out.append({"role": m["role"], "content": c})
        return out

    def chat(self, prompt, on_delta=None, cancel=None):
        """Send a prompt (str, or a list of content parts with images), streaming
        deltas to on_delta. Returns the full answer."""
        if isinstance(prompt, str) and len(prompt) > MAX_PROMPT_CHARS:
            raise ApiError("Prompt is too large for a safe API request")
        self.history.append({"role": "user", "content": prompt})
        self._throttle()
        try:
            payload = {"model": self.model, "messages": self._messages(), "stream": True}
            req = urllib.request.Request(
                self._chat_url(), data=json.dumps(payload).encode("utf-8"),
                headers=self.headers(), method="POST")
            parts = []
            try:
                resp = urllib.request.urlopen(req, timeout=120)
            except urllib.error.HTTPError as exc:
                raise ApiError(_http_error_message(exc))
            except urllib.error.URLError as exc:
                raise ApiError("Network error: %s" % exc.reason)
            with resp:
                ctype = resp.headers.get("Content-Type", "")
                if "text/event-stream" not in ctype:
                    raw_body = resp.read(MAX_RESPONSE_BYTES + 1)
                    if len(raw_body) > MAX_RESPONSE_BYTES:
                        raise ApiError("API response exceeded safety limit")
                    data = json.loads(raw_body.decode("utf-8", "replace"))
                    if "error" in data:
                        err = data["error"]
                        raise ApiError(err.get("message", str(err)) if isinstance(err, dict) else str(err))
                    text = data["choices"][0]["message"]["content"] or ""
                    parts.append(text)
                    if on_delta and text:
                        on_delta(text)
                else:
                    for raw in resp:
                        if cancel is not None and cancel.is_set():
                            raise Cancelled()
                        line = raw.decode("utf-8", "replace").strip()
                        if not line.startswith("data:"):
                            continue
                        chunk = line[5:].strip()
                        if chunk == "[DONE]":
                            break
                        try:
                            obj = json.loads(chunk)
                        except ValueError:
                            continue
                        if "error" in obj:
                            err = obj["error"]
                            raise ApiError(err.get("message", str(err)) if isinstance(err, dict) else str(err))
                        choices = obj.get("choices") or []
                        delta = (choices[0].get("delta") or {}).get("content") if choices else None
                        if delta:
                            parts.append(delta)
                            if on_delta:
                                on_delta(delta)
            answer = "".join(parts)
            self.history.append({"role": "assistant", "content": answer})
            return answer
        except BaseException:
            if self.history and self.history[-1]["role"] == "user":
                self.history.pop()
            raise

    def models(self):
        self._throttle()
        req = urllib.request.Request(self._models_url(), headers=self.headers())
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8", "replace"))
        except urllib.error.HTTPError as exc:
            raise ApiError(_http_error_message(exc))
        except urllib.error.URLError as exc:
            raise ApiError("Network error: %s" % exc.reason)
        items = data.get("data", [])
        return sorted(
            [{"id": x.get("id", ""), "name": x.get("name") or x.get("id", "")}
             for x in items if x.get("id")],
            key=lambda x: x["id"].lower(),
        )
