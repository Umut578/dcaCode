"""Attachments, skills, project templates, AI file extraction and sharing.

Standard library only; no curses here so everything is unit-testable.
"""
import base64
import os
import re
import shlex
import shutil
import struct
import subprocess
import tempfile
import time
import zipfile
from pathlib import Path
from urllib.parse import unquote, urlparse

IGNORED = {"__pycache__", ".venv", "venv", "node_modules", ".git", ".mypy_cache", ".pytest_cache"}
SHARE_DIR = "dcacode-share"
IMG_EXT = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
           ".gif": "image/gif", ".webp": "image/webp"}
MAX_IMG = 5000000
MAX_TEXT_FILE = 1000000
MAX_TEXT = 60000
MAX_WRITE = 1000000
MAX_WRITE_FILES = 50


def fence_for(text):
    runs = re.findall(r"`+", text)
    return "`" * max(3, max((len(r) for r in runs), default=0) + 1)


def is_secret(name):
    n = name.lower()
    return n == "api.env" or n.endswith(".env") or n.endswith((".pem", ".key")) or n.startswith("id_rsa")


# ------------------------------------------------------------------ attachments
AUDIO_EXT = {".mp3": "mp3", ".wav": "wav"}
VIDEO_EXT = {".mp4": "video/mp4", ".webm": "video/webm", ".mov": "video/quicktime"}
MEDIA_EXT = set(IMG_EXT) | set(AUDIO_EXT) | set(VIDEO_EXT) | {".avi", ".iso"}
MAX_AUDIO = 15000000
MAX_VIDEO = 20000000
SUPPORTED = ("text/code (html, htm, htmls, js, css, ...), images (png, jpg, gif, webp), "
             "audio (mp3, wav), video (mp4, webm, mov, avi), disk images (iso), folders")


def human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" % (n, unit)) if unit == "B" else ("%.1f %s" % (n, unit))
        n /= 1024.0


def dropped_path(text):
    """Path pasted/dropped into the chat input (absolute, ~ or file://), else None."""
    s = text.strip()
    if not s:
        return None
    if s.startswith("file://"):
        s = unquote(urlparse(s).path)
    else:
        try:
            parts = shlex.split(s)
        except ValueError:
            return None
        if len(parts) != 1:
            return None
        s = parts[0]
    if not (s.startswith("/") or s.startswith("~") or re.match(r"^[A-Za-z]:[\\/]", s)):
        return None
    p = Path(os.path.expanduser(s))
    return p if p.exists() else None


def _read_text(path):
    """Return text or raise ValueError."""
    if path.stat().st_size > MAX_TEXT_FILE:
        raise ValueError("%s is larger than 1 MB" % path.name)
    raw = path.read_bytes()
    if b"\x00" in raw[:8192]:
        raise ValueError("%s: unsupported binary file. Supported: %s" % (path.name, SUPPORTED))
    try:
        return raw.decode("utf-8")
    except UnicodeDecodeError:
        raise ValueError("%s is not UTF-8 text" % path.name)


def collect_folder(path, max_files=60, max_total=200000, max_each=40000):
    chunks, count, skipped, total = [], 0, 0, 0
    for dirpath, dirnames, filenames in os.walk(str(path)):
        dirnames[:] = sorted(d for d in dirnames
                             if not d.startswith(".") and d not in IGNORED and d != SHARE_DIR)
        for fn in sorted(filenames):
            fp = Path(dirpath) / fn
            if fn.startswith(".") or is_secret(fn) or fp.suffix.lower() in MEDIA_EXT:
                skipped += 1
                continue
            try:
                text = _read_text(fp)
            except (ValueError, OSError):
                skipped += 1
                continue
            text = text[:max_each]
            if count >= max_files or total + len(text) > max_total:
                skipped += 1
                continue
            f = fence_for(text)
            chunks.append("### %s\n%s\n%s\n%s" % (fp.relative_to(path).as_posix(), f, text, f))
            count += 1
            total += len(text)
    if not count:
        raise ValueError("no readable text files in %s" % path.name)
    head = "Attached folder: %s (%d files%s)" % (
        path.name, count, ", %d skipped" % skipped if skipped else "")
    return {"kind": "folder", "name": path.name + "/", "text": head + "\n\n" + "\n\n".join(chunks),
            "size": total, "count": count}


# -- media metadata (pure Python) ------------------------------------------
def _dur(sec):
    sec = int(round(sec))
    return "%d:%02d" % (sec // 60, sec % 60) if sec >= 60 else "%d s" % sec


def wav_info(path):
    try:
        with open(str(path), "rb") as f:
            head = f.read(4096)
        if head[:4] != b"RIFF" or head[8:12] != b"WAVE":
            return ""
        pos, ch, rate, bits, dsize = 12, 0, 0, 0, 0
        while pos + 8 <= len(head):
            cid, csz = head[pos:pos + 4], struct.unpack_from("<I", head, pos + 4)[0]
            if cid == b"fmt " and pos + 24 <= len(head):
                ch, rate = struct.unpack_from("<HI", head, pos + 10)
                bits = struct.unpack_from("<H", head, pos + 22)[0]
            elif cid == b"data":
                dsize = csz
                break
            pos += 8 + csz + (csz & 1)
        if rate and ch and bits and dsize:
            return "%d Hz, %d ch, %d-bit, %s" % (rate, ch, bits, _dur(dsize / float(rate * ch * bits // 8)))
    except (OSError, struct.error, ZeroDivisionError):
        pass
    return ""


def avi_info(path):
    try:
        with open(str(path), "rb") as f:
            head = f.read(8192)
        if head[:4] != b"RIFF" or head[8:12] != b"AVI ":
            return ""
        i = head.find(b"avih")
        usec, _, _, _, frames, _, _, _, w, h = struct.unpack_from("<10I", head, i + 8)
        fps = 1e6 / usec if usec else 0
        return "%dx%d, %.1f fps, %s" % (w, h, fps, _dur(frames * usec / 1e6)) if usec else "%dx%d" % (w, h)
    except (OSError, struct.error):
        return ""


def _atoms(data, start, end):
    pos = start
    while pos + 8 <= end:
        size, typ = struct.unpack_from(">I4s", data, pos)
        hdr = 8
        if size == 1 and pos + 16 <= end:
            size = struct.unpack_from(">Q", data, pos + 8)[0]
            hdr = 16
        elif size == 0:
            size = end - pos
        if size < hdr:
            return
        yield typ, pos + hdr, min(pos + size, end)
        pos += size


def mp4_info(path):
    try:
        with open(str(path), "rb") as f:
            total = os.fstat(f.fileno()).st_size
            pos = 0
            while pos + 8 <= total:
                f.seek(pos)
                size, typ = struct.unpack(">I4s", f.read(8))
                hdr = 8
                if size == 1:
                    size = struct.unpack(">Q", f.read(8))[0]
                    hdr = 16
                elif size == 0:
                    size = total - pos
                if size < hdr:
                    return ""
                if typ == b"moov" and size < 16000000:
                    f.seek(pos + hdr)
                    data = f.read(size - hdr)
                    return _moov_info(data)
                pos += size
    except (OSError, struct.error):
        pass
    return ""


def _moov_info(data):
    dur, width, height = 0.0, 0, 0
    for typ, a, b in _atoms(data, 0, len(data)):
        if typ == b"mvhd":
            ver = data[a]
            if ver == 1:
                ts, d = struct.unpack_from(">IQ", data, a + 20)
            else:
                ts, d = struct.unpack_from(">II", data, a + 12)
            dur = d / float(ts) if ts else 0.0
        elif typ == b"trak":
            for t2, a2, b2 in _atoms(data, a, b):
                if t2 == b"tkhd":
                    w, h = struct.unpack_from(">II", data, b2 - 8)
                    if w and h and not width:
                        width, height = w >> 16, h >> 16
    bits = []
    if width:
        bits.append("%dx%d" % (width, height))
    if dur:
        bits.append(_dur(dur))
    return ", ".join(bits)


def ffmpeg_to_mp4(path, max_bytes):
    """Optional: convert/shrink a video with a system ffmpeg. None if unavailable."""
    exe = shutil.which("ffmpeg")
    if not exe:
        return None
    tmp = tempfile.mkdtemp(prefix="dcacode-")
    out = os.path.join(tmp, "out.mp4")
    cmd = [exe, "-v", "error", "-y", "-i", str(path), "-vf", "scale=min(854\\,iw):-2",
           "-c:v", "libx264", "-crf", "30", "-preset", "veryfast", "-c:a", "aac", "-b:a", "64k",
           "-movflags", "+faststart", out]
    try:
        subprocess.run(cmd, timeout=240, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                       stderr=subprocess.DEVNULL, check=True)
        with open(out, "rb") as fh:
            data = fh.read()
    except Exception:
        data = None
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    return data if data and len(data) <= max_bytes else None


def _b64(data):
    return base64.b64encode(data).decode("ascii")


def _media_text(kind, name, size, info, note):
    bits = [x for x in (human(size), info) if x]
    text = "Attached %s: %s (%s)" % (kind, name, ", ".join(bits))
    return text + ("\n" + note if note else "")


def _image(path, ext, size):
    if size > MAX_IMG:
        raise ValueError("%s is larger than 5 MB" % path.name)
    return {"kind": "image", "name": path.name, "size": size,
            "note": "needs a vision-capable model",
            "part": {"type": "image_url", "image_url": {"url": "data:%s;base64,%s" % (
                IMG_EXT[ext], _b64(path.read_bytes()))}}}


def _audio(path, ext, size):
    info = wav_info(path) if ext == ".wav" else ""
    if size > MAX_AUDIO:
        note = "Too large to upload (limit 15 MB): only metadata was sent."
        return {"kind": "audio", "name": path.name, "size": size, "note": "metadata only (>15 MB)",
                "text": _media_text("audio", path.name, size, info, note)}
    return {"kind": "audio", "name": path.name, "size": size, "note": "needs an audio-capable model",
            "text": _media_text("audio", path.name, size, info, ""),
            "part": {"type": "input_audio", "input_audio": {"data": _b64(path.read_bytes()),
                                                            "format": AUDIO_EXT[ext]}}}


def _video(path, ext, size):
    info = avi_info(path) if ext == ".avi" else mp4_info(path)
    data, note, mime = None, "", VIDEO_EXT.get(ext, "video/mp4")
    if ext == ".avi" or size > MAX_VIDEO:
        data = ffmpeg_to_mp4(path, MAX_VIDEO)
        if data:
            mime, note = "video/mp4", "Converted/shrunk to MP4 with ffmpeg before upload."
        else:
            note = "Not uploaded (needs ffmpeg for AVI or videos over 20 MB): only metadata was sent."
    else:
        data = path.read_bytes()
    att = {"kind": "video", "name": path.name, "size": size,
           "text": _media_text("video", path.name, size, info, note)}
    if data:
        att["note"] = "needs a video-capable model" + (" (converted by ffmpeg)" if note else "")
        att["part"] = {"type": "video_url", "video_url": {"url": "data:%s;base64,%s" % (mime, _b64(data))}}
    else:
        att["note"] = "metadata only"
    return att


# -- ISO 9660 ----------------------------------------------------------------
_PREVIEW = re.compile(r"(readme|\.txt$|\.cfg$|\.conf$|\.md$|\.json$|\.sh$|\.ini$|\.lst$|\.html?$)", re.I)


def iso_attachment(path, max_entries=400, max_previews=5):
    size = path.stat().st_size
    with open(str(path), "rb") as f:
        def read_at(off, n):
            f.seek(off)
            return f.read(n)

        primary = joliet = None
        boot = False
        for i in range(16, 16 + 64):
            sec = read_at(i * 2048, 2048)
            if len(sec) < 2048 or sec[1:6] != b"CD001" or sec[0] == 255:
                break
            if sec[0] == 0 and b"EL TORITO" in sec[7:39]:
                boot = True
            elif sec[0] == 1 and primary is None:
                primary = sec
            elif sec[0] == 2 and sec[88:91] in (b"%/@", b"%/C", b"%/E"):
                joliet = sec
        if primary is None:
            text = ("Attached disk image: %s (%s) - not a recognised ISO 9660 image "
                    "(maybe UDF or another format); only the file size is known." % (path.name, human(size)))
            return {"kind": "disk", "name": path.name, "size": size, "text": text, "note": "unrecognised ISO"}
        vd = joliet or primary
        enc = "utf-16-be" if joliet else "ascii"
        label = primary[40:72].decode("ascii", "replace").strip()
        block = struct.unpack_from("<H", vd, 128)[0] or 2048
        root_ext, root_len = struct.unpack_from("<I", vd, 158)[0], struct.unpack_from("<I", vd, 166)[0]

        def parse_dir(extent, length):
            data = read_at(extent * block, min(length, 1048576))
            pos, out = 0, []
            while pos < len(data):
                ln = data[pos]
                if ln == 0:
                    pos = (pos // block + 1) * block
                    continue
                rec = data[pos:pos + ln]
                pos += ln
                if len(rec) < 34:
                    continue
                ext, dlen, flags, nl = struct.unpack_from("<I", rec, 2)[0], struct.unpack_from("<I", rec, 10)[0], rec[25], rec[32]
                nb = rec[33:33 + nl]
                if nb in (b"\x00", b"\x01"):
                    continue
                name = re.sub(r";\d+$", "", nb.decode(enc, "replace"))
                out.append((name, ext, dlen, bool(flags & 2)))
            return out

        entries, previews, todo, seen = [], [], [("", root_ext, root_len, 0)], set()
        while todo and len(entries) < max_entries:
            prefix, ext, ln, depth = todo.pop(0)
            if ext in seen:
                continue
            seen.add(ext)
            for name, e, l, isdir in parse_dir(ext, ln):
                full = prefix + name + ("/" if isdir else "")
                entries.append((full, l, isdir))
                if isdir and depth < 6:
                    todo.append((full, e, l, depth + 1))
                elif not isdir and len(previews) < max_previews and _PREVIEW.search(name):
                    previews.append((full, e, l))
                if len(entries) >= max_entries:
                    break
        pre_text = []
        for full, e, l in previews:
            raw = read_at(e * block, min(l, 4000))
            if b"\x00" in raw:
                continue
            try:
                body = raw.decode("utf-8")
            except UnicodeDecodeError:
                continue
            fc = fence_for(body)
            pre_text.append("### inside ISO: %s\n%s\n%s\n%s" % (full, fc, body, fc))
    head = "Attached disk image: %s (ISO 9660%s, volume '%s', %s%s)" % (
        path.name, " + Joliet" if joliet else "", label, human(size), ", bootable (El Torito)" if boot else "")
    lines = ["  %s%s" % (p, "" if d else "  (%s)" % human(l)) for p, l, d in entries]
    more = "\n  ... (list truncated at %d entries)" % max_entries if len(entries) >= max_entries else ""
    text = head + "\nContents:\n" + "\n".join(lines) + more
    if pre_text:
        text += "\n\n" + "\n\n".join(pre_text)
    return {"kind": "disk", "name": path.name, "size": size, "text": text,
            "note": "%d entries listed" % len(entries)}


def load_attachment(path):
    """Load a file, photo, audio, video, disk image or folder. Raises ValueError."""
    path = Path(path)
    if path.is_dir():
        return collect_folder(path)
    if not path.is_file():
        raise ValueError("not found: %s" % path)
    ext, size = path.suffix.lower(), path.stat().st_size
    if ext in IMG_EXT:
        return _image(path, ext, size)
    if ext in AUDIO_EXT:
        return _audio(path, ext, size)
    if ext in VIDEO_EXT or ext == ".avi":
        return _video(path, ext, size)
    if ext == ".iso":
        return iso_attachment(path)
    text = _read_text(path)
    note = ""
    if len(text) > MAX_TEXT:
        text, note = text[:MAX_TEXT], " (truncated)"
    f = fence_for(text)
    return {"kind": "file", "name": path.name, "size": size,
            "text": "Attached file: %s%s\n%s\n%s\n%s" % (path.name, note, f, text, f)}


def build_content(question, attachments):
    """Chat message content: a string, or OpenAI-style parts when media is attached."""
    texts = [a["text"] for a in attachments if a.get("text")]
    parts = [a["part"] for a in attachments if a.get("part")]
    body = "\n\n".join(texts + [question]) if texts else question
    if not parts:
        return body
    return [{"type": "text", "text": body}] + parts


# ------------------------------------------------------------------ AI-created files
_LABEL = re.compile(r"^(?:file(?:name)?|path|dosya(?: adı)?)\s*[:：]\s*(.+)$", re.I)
_INFO_KV = re.compile(r"(?:file|path|filename|title)\s*=\s*[\"']?([^\"'\s]+)", re.I)
_HEAD_COMMENT = re.compile(
    r"^\s*(?:#|//|--|/\*|<!--)\s*(?:file|path|filename)\s*[:=]\s*(\S+?)\s*(?:\*/|-->)?\s*$", re.I)
_FENCE = re.compile(r"^(\s*)(`{3,})(.*)$")


def sanitize_rel(p):
    p = (p or "").strip().strip("`*\"' ").replace("\\", "/")
    while p.startswith("./"):
        p = p[2:]
    if not p or p.startswith("/") or re.match(r"^[A-Za-z]:", p) or len(p) > 200:
        return None
    parts = p.split("/")
    if any(x in ("", "..") for x in parts):
        return None
    return p


def looks_like_path(s):
    s = s.strip()
    if not s or len(s) > 200 or s.lower().startswith(("http:", "https:")):
        return False
    if not re.match(r"^[\w.\-/\\@+]+$", s):
        return False
    base = re.split(r"[/\\]", s)[-1]
    return "." in base.strip(".") or base in ("Makefile", "Dockerfile", "LICENSE", "Procfile")


def _path_from_line(line):
    t = line.strip().lstrip("#").strip().strip("*`").strip().rstrip(":").strip("*` ")
    m = _LABEL.match(t)
    if m:
        t = m.group(1).strip().strip("*`\"' ")
    return t if looks_like_path(t) else None


def extract_files(answer):
    """Find fenced code blocks that carry a file path. Returns [(rel_path, content)].

    Recognised: ```lang file=path```, ```lang path```, a preceding line such as
    'File: path' / '**path**', or a first body line like '# file: path'."""
    out = {}
    lines = answer.split("\n")
    i, prev = 0, ""
    while i < len(lines):
        m = _FENCE.match(lines[i])
        if not m:
            if lines[i].strip():
                prev = lines[i]
            i += 1
            continue
        indent, ticks, info = m.group(1), len(m.group(2)), m.group(3).strip()
        body = []
        i += 1
        while i < len(lines):
            c = _FENCE.match(lines[i])
            if c and len(c.group(2)) >= ticks and not c.group(3).strip():
                break
            line = lines[i]
            if indent and line.startswith(indent):
                line = line[len(indent):]
            body.append(line)
            i += 1
        i += 1  # closing fence
        cand = None
        kv = _INFO_KV.search(info)
        if kv:
            cand = kv.group(1)
        else:
            toks = info.replace(":", " ").split()
            for t in toks[1:]:
                if looks_like_path(t):
                    cand = t
                    break
        if cand is None:
            cand = _path_from_line(prev)
        if cand is None and body:
            hm = _HEAD_COMMENT.match(body[0])
            if hm:
                cand = hm.group(1)
        prev = ""
        rel = sanitize_rel(cand) if cand else None
        if rel:
            out[rel] = "\n".join(body).rstrip("\n") + "\n"
    return list(out.items())[:MAX_WRITE_FILES]


# ------------------------------------------------------------------ project templates
TEMPLATES = {
    "python": {
        "main.py": 'def main():\n    print("Hello from __NAME__!")\n\n\nif __name__ == "__main__":\n    main()\n',
        "README.md": "# __NAME__\n\nRun with `python3 main.py`.\n",
        ".gitignore": "__pycache__/\n*.pyc\n.venv/\n",
    },
    "web": {
        "index.html": '<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="utf-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1">\n  <title>__NAME__</title>\n  <link rel="stylesheet" href="style.css">\n</head>\n<body>\n  <h1>__NAME__</h1>\n  <script src="app.js"></script>\n</body>\n</html>\n',
        "style.css": "body {\n  font-family: system-ui, sans-serif;\n  margin: 2rem;\n}\n",
        "app.js": 'console.log("__NAME__ ready");\n',
    },
    "bash": {
        "main.sh": '#!/usr/bin/env bash\nset -euo pipefail\n\necho "Hello from __NAME__!"\n',
        "README.md": "# __NAME__\n\nRun with `bash main.sh`.\n",
    },
    "empty": {
        "README.md": "# __NAME__\n",
    },
}
TEMPLATE_INFO = {
    "python": "main.py, README, .gitignore",
    "web": "index.html, style.css, app.js",
    "bash": "main.sh, README",
    "empty": "README only (good with an AI description)",
}


def create_project(parent, name, template="python"):
    if not re.match(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$", name or ""):
        raise ValueError("project name: letters, digits, . _ - (max 64)")
    if template not in TEMPLATES:
        raise ValueError("unknown template '%s' (%s)" % (template, ", ".join(TEMPLATES)))
    path = Path(parent) / name
    if path.exists() and (not path.is_dir() or any(path.iterdir())):
        raise ValueError("%s already exists and is not empty" % path)
    path.mkdir(parents=True, exist_ok=True)
    for rel, content in TEMPLATES[template].items():
        (path / rel).write_text(content.replace("__NAME__", name), encoding="utf-8")
    return path


# ------------------------------------------------------------------ skills
BUILTIN_SKILLS = {
    "code-review": "Review code like a careful senior engineer. List real bugs first, then risks, then style. "
                   "Quote the exact line for each finding and keep every suggestion short and concrete.",
    "python-style": "Write clean, idiomatic Python: PEP 8, small functions, descriptive names, standard library first, "
                    "brief docstrings. Avoid needless dependencies.",
    "write-tests": "When code is shown, propose focused tests (pytest or unittest) covering normal cases, edge cases "
                   "and failures. Output complete, runnable test files.",
    "explain-simply": "Explain step by step in simple words with one tiny example. Avoid jargon unless you define it.",
    "minimal-diff": "When changing code, change as little as possible. Do not rename or reformat unrelated code. "
                    "Output complete files only for the files that actually changed.",
}


def skill_dirs(root):
    return [("user", Path.home() / ".config" / "dcacode" / "skills"),
            ("project", Path(root) / ".dcacode" / "skills")]


def valid_skill_name(name):
    return bool(re.match(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,48}$", name or ""))


def list_skills(root):
    """name -> {'text', 'source', 'desc'}; project overrides user overrides built-in."""
    skills = {n: {"text": t, "source": "built-in"} for n, t in BUILTIN_SKILLS.items()}
    for source, d in skill_dirs(root):
        try:
            files = sorted(d.glob("*.md"))
        except OSError:
            continue
        for f in files:
            if not valid_skill_name(f.stem):
                continue
            try:
                skills[f.stem] = {"text": f.read_text(encoding="utf-8").strip(), "source": source}
            except (OSError, UnicodeDecodeError):
                continue
    for s in skills.values():
        first = next((x.strip().lstrip("#").strip() for x in s["text"].splitlines() if x.strip()), "")
        s["desc"] = first[:70]
    return skills


def skills_prompt(root, names):
    if not names:
        return ""
    skills = list_skills(root)
    parts = ["### %s\n%s" % (n, skills[n]["text"][:6000]) for n in names if n in skills]
    if not parts:
        return ""
    return "The user activated these skills. Follow them:\n\n" + "\n\n".join(parts)


def skill_template(name):
    return ("# %s\n\nDescribe here how the assistant should behave when this skill is active.\n"
            "Examples: coding style rules, review checklist, answer format, project conventions.\n" % name)


# ------------------------------------------------------------------ sharing
def iter_share_files(root, only=None):
    root = Path(root)
    if only is not None:
        for rel in only:
            fp = root / rel
            if fp.is_file() and not is_secret(fp.name):
                yield fp
        return
    for dirpath, dirnames, filenames in os.walk(str(root)):
        dirnames[:] = sorted(d for d in dirnames
                             if not d.startswith(".") and d not in IGNORED and d != SHARE_DIR)
        for fn in sorted(filenames):
            if fn.startswith(".") and fn != ".gitignore":
                continue
            if is_secret(fn) or fn.endswith((".pyc", ".deb", ".zip")):
                continue
            yield Path(dirpath) / fn


def make_zip(root, label, only=None):
    """Zip the project (or only the listed relative paths) into <root>/dcacode-share/."""
    root = Path(root)
    dest = root / SHARE_DIR
    files = list(iter_share_files(root, only))
    if not files:
        raise ValueError("nothing to share")
    dest.mkdir(parents=True, exist_ok=True)
    safe = re.sub(r"[^A-Za-z0-9._-]", "-", label) or "project"
    out = dest / ("%s-%s.zip" % (safe, time.strftime("%Y%m%d-%H%M%S")))
    with zipfile.ZipFile(str(out), "w", zipfile.ZIP_DEFLATED) as z:
        for fp in files:
            z.write(str(fp), root.name + "/" + fp.relative_to(root).as_posix())
    return out, len(files), out.stat().st_size
