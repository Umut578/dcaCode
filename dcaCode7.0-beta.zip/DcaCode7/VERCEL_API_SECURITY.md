# dcaCode — Vercel API Proxy

This package adds a server-side OpenRouter proxy. The desktop app sends requests to your Vercel endpoint and does not need to contain the upstream OpenRouter key.

## Deploy
1. Push this folder to a private or public GitHub repository (the upstream key is not in the source).
2. Import the repository into Vercel. Keep the project root at the folder containing `api/`.
3. In Vercel → Project → Settings → Environment Variables, add `OPENROUTER_API_KEY` with your OpenRouter key. Add it to Production (and Preview only if needed).
4. Optionally set `ALLOWED_ORIGINS` to comma-separated exact browser origins. Native desktop clients commonly send no Origin header.
5. Deploy, then set `DCACODE_API_PROXY_URL=https://YOUR-PROJECT.vercel.app` in the environment before starting dcaCode.
6. In the app, clear the locally saved OpenRouter key if you want to use proxy-only mode.

## Security notes
- Never commit `.env`, `api.env`, or real credentials. `.gitignore` excludes them.
- Rotate any key that was previously committed or exposed; deleting it from Git history is not enough.
- The proxy enforces method, body-size, message-count, model-length, streaming, and best-effort per-IP limits.
- The included in-memory rate limiter is per serverless instance, not a durable global quota. For public production use, add Upstash Redis/Vercel Firewall or another shared rate limiter, plus user authentication and per-user quotas.
- CORS is not authentication. A public desktop app cannot keep a shared proxy password secret. Without user sign-in or another trusted identity mechanism, determined callers can still use the public endpoint and potentially consume your API budget. Configure provider spending limits/alerts as well.
- The proxy protects the upstream OpenRouter key from being shipped in GitHub/source/client code; it does not make a public endpoint abuse-proof.
